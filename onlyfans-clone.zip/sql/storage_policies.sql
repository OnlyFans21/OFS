-- ============================================================
-- ONLYFANS CLONE - STORAGE POLICIES
-- Run this AFTER migration.sql and rls_policies.sql
-- Compatible with latest Supabase (handles permission constraints)
-- ============================================================

-- Step 1: Take ownership of storage.objects so we can manage policies
DO $$
BEGIN
    EXECUTE format('ALTER TABLE storage.objects OWNER TO %I', current_user);
EXCEPTION WHEN OTHERS THEN
    RAISE NOTICE 'Note: Could not change ownership of storage.objects: %', SQLERRM;
END $$;

-- Step 2: Grant full access to required roles
DO $$
BEGIN
    GRANT ALL ON TABLE storage.objects TO authenticated, anon, service_role;
EXCEPTION WHEN OTHERS THEN
    RAISE NOTICE 'Note: Could not grant on storage.objects: %', SQLERRM;
END $$;

-- Step 3: Enable RLS on storage.objects (idempotent)
DO $$
BEGIN
    ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;
EXCEPTION WHEN OTHERS THEN
    RAISE NOTICE 'Note: Could not enable RLS on storage.objects: %', SQLERRM;
END $$;

-- Step 4: Drop existing policies safely
DO $$
BEGIN
    DROP POLICY IF EXISTS "avatars_select" ON storage.objects;
    DROP POLICY IF EXISTS "avatars_insert" ON storage.objects;
    DROP POLICY IF EXISTS "avatars_delete" ON storage.objects;
    DROP POLICY IF EXISTS "covers_select" ON storage.objects;
    DROP POLICY IF EXISTS "covers_insert" ON storage.objects;
    DROP POLICY IF EXISTS "covers_delete" ON storage.objects;
    DROP POLICY IF EXISTS "photos_select" ON storage.objects;
    DROP POLICY IF EXISTS "photos_insert" ON storage.objects;
    DROP POLICY IF EXISTS "photos_delete" ON storage.objects;
    DROP POLICY IF EXISTS "videos_select" ON storage.objects;
    DROP POLICY IF EXISTS "videos_insert" ON storage.objects;
    DROP POLICY IF EXISTS "videos_delete" ON storage.objects;
    DROP POLICY IF EXISTS "chat_select" ON storage.objects;
    DROP POLICY IF EXISTS "chat_insert" ON storage.objects;
    DROP POLICY IF EXISTS "chat_delete" ON storage.objects;
EXCEPTION WHEN OTHERS THEN
    RAISE NOTICE 'Note: Could not drop some policies: %', SQLERRM;
END $$;

-- Step 5: Create policies using SECURITY DEFINER function approach
-- This bypasses the ownership issue by running with elevated privileges

CREATE OR REPLACE FUNCTION public.create_storage_policies()
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, storage
AS $$
DECLARE
    result TEXT := '';
BEGIN
    -- AVATARS
    BEGIN
        CREATE POLICY "avatars_select" ON storage.objects FOR SELECT USING (bucket_id = 'avatars');
        result := result || 'avatars_select OK. ';
    EXCEPTION WHEN OTHERS THEN result := result || 'avatars_select FAIL: ' || SQLERRM || '. '; END;

    BEGIN
        CREATE POLICY "avatars_insert" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'avatars' AND auth.uid() IS NOT NULL AND (storage.foldername(name))[1] = auth.uid()::text);
        result := result || 'avatars_insert OK. ';
    EXCEPTION WHEN OTHERS THEN result := result || 'avatars_insert FAIL: ' || SQLERRM || '. '; END;

    BEGIN
        CREATE POLICY "avatars_delete" ON storage.objects FOR DELETE USING (bucket_id = 'avatars' AND auth.uid() IS NOT NULL AND (storage.foldername(name))[1] = auth.uid()::text);
        result := result || 'avatars_delete OK. ';
    EXCEPTION WHEN OTHERS THEN result := result || 'avatars_delete FAIL: ' || SQLERRM || '. '; END;

    -- COVERS
    BEGIN
        CREATE POLICY "covers_select" ON storage.objects FOR SELECT USING (bucket_id = 'covers');
        result := result || 'covers_select OK. ';
    EXCEPTION WHEN OTHERS THEN result := result || 'covers_select FAIL: ' || SQLERRM || '. '; END;

    BEGIN
        CREATE POLICY "covers_insert" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'covers' AND auth.uid() IS NOT NULL AND (storage.foldername(name))[1] = auth.uid()::text);
        result := result || 'covers_insert OK. ';
    EXCEPTION WHEN OTHERS THEN result := result || 'covers_insert FAIL: ' || SQLERRM || '. '; END;

    BEGIN
        CREATE POLICY "covers_delete" ON storage.objects FOR DELETE USING (bucket_id = 'covers' AND auth.uid() IS NOT NULL AND (storage.foldername(name))[1] = auth.uid()::text);
        result := result || 'covers_delete OK. ';
    EXCEPTION WHEN OTHERS THEN result := result || 'covers_delete FAIL: ' || SQLERRM || '. '; END;

    -- PHOTOS
    BEGIN
        CREATE POLICY "photos_select" ON storage.objects FOR SELECT USING (bucket_id = 'photos');
        result := result || 'photos_select OK. ';
    EXCEPTION WHEN OTHERS THEN result := result || 'photos_select FAIL: ' || SQLERRM || '. '; END;

    BEGIN
        CREATE POLICY "photos_insert" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'photos' AND auth.uid() IS NOT NULL AND (storage.foldername(name))[1] = auth.uid()::text);
        result := result || 'photos_insert OK. ';
    EXCEPTION WHEN OTHERS THEN result := result || 'photos_insert FAIL: ' || SQLERRM || '. '; END;

    BEGIN
        CREATE POLICY "photos_delete" ON storage.objects FOR DELETE USING (bucket_id = 'photos' AND auth.uid() IS NOT NULL AND (storage.foldername(name))[1] = auth.uid()::text);
        result := result || 'photos_delete OK. ';
    EXCEPTION WHEN OTHERS THEN result := result || 'photos_delete FAIL: ' || SQLERRM || '. '; END;

    -- VIDEOS
    BEGIN
        CREATE POLICY "videos_select" ON storage.objects FOR SELECT USING (bucket_id = 'videos');
        result := result || 'videos_select OK. ';
    EXCEPTION WHEN OTHERS THEN result := result || 'videos_select FAIL: ' || SQLERRM || '. '; END;

    BEGIN
        CREATE POLICY "videos_insert" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'videos' AND auth.uid() IS NOT NULL AND (storage.foldername(name))[1] = auth.uid()::text);
        result := result || 'videos_insert OK. ';
    EXCEPTION WHEN OTHERS THEN result := result || 'videos_insert FAIL: ' || SQLERRM || '. '; END;

    BEGIN
        CREATE POLICY "videos_delete" ON storage.objects FOR DELETE USING (bucket_id = 'videos' AND auth.uid() IS NOT NULL AND (storage.foldername(name))[1] = auth.uid()::text);
        result := result || 'videos_delete OK. ';
    EXCEPTION WHEN OTHERS THEN result := result || 'videos_delete FAIL: ' || SQLERRM || '. '; END;

    -- CHAT FILES
    BEGIN
        CREATE POLICY "chat_select" ON storage.objects FOR SELECT USING (bucket_id = 'chat-files' AND auth.uid() IS NOT NULL);
        result := result || 'chat_select OK. ';
    EXCEPTION WHEN OTHERS THEN result := result || 'chat_select FAIL: ' || SQLERRM || '. '; END;

    BEGIN
        CREATE POLICY "chat_insert" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'chat-files' AND auth.uid() IS NOT NULL AND (storage.foldername(name))[1] = auth.uid()::text);
        result := result || 'chat_insert OK. ';
    EXCEPTION WHEN OTHERS THEN result := result || 'chat_insert FAIL: ' || SQLERRM || '. '; END;

    BEGIN
        CREATE POLICY "chat_delete" ON storage.objects FOR DELETE USING (bucket_id = 'chat-files' AND auth.uid() IS NOT NULL AND (storage.foldername(name))[1] = auth.uid()::text);
        result := result || 'chat_delete OK. ';
    EXCEPTION WHEN OTHERS THEN result := result || 'chat_delete FAIL: ' || SQLERRM || '. '; END;

    RETURN result;
END;
$$;

-- Execute the function to create all policies
SELECT public.create_storage_policies() AS policy_status;

-- Clean up: drop the helper function after use
DROP FUNCTION IF EXISTS public.create_storage_policies();

SELECT 'Storage policies setup complete!' AS status;
