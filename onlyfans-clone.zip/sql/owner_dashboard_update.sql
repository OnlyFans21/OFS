-- ============================================================
-- ONLYFANS CLONE - OWNER DASHBOARD UPDATE
-- Run this AFTER the 3 main SQL files
-- Adds: revenue tracking, post boosts, subscription monitoring
-- ============================================================

-- 1. Add is_boosted flag to posts + admin_password for creators
DO $$ BEGIN
    ALTER TABLE posts ADD COLUMN IF NOT EXISTS is_boosted BOOLEAN DEFAULT FALSE;
    ALTER TABLE posts ADD COLUMN IF NOT EXISTS boost_count INTEGER DEFAULT 0;
EXCEPTION WHEN OTHERS THEN
    RAISE NOTICE 'Note: Could not add boost columns: %', SQLERRM;
END $$;

DO $$ BEGIN
    ALTER TABLE profiles ADD COLUMN IF NOT EXISTS admin_password TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN
    RAISE NOTICE 'Note: Could not add admin_password: %', SQLERRM;
END $$;

-- 1b. Add QR code URLs to creator_payment_settings
DO $$ BEGIN
    ALTER TABLE creator_payment_settings ADD COLUMN IF NOT EXISTS btc_qr_url TEXT DEFAULT '';
    ALTER TABLE creator_payment_settings ADD COLUMN IF NOT EXISTS usdt_qr_url TEXT DEFAULT '';
EXCEPTION WHEN OTHERS THEN
    RAISE NOTICE 'Note: Could not add QR columns: %', SQLERRM;
END $$;

-- 2. Create post_boosts table (tracks owner-added likes)
CREATE TABLE IF NOT EXISTS post_boosts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    post_id UUID NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
    owner_id UUID NOT NULL,
    likes_added INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. RLS for post_boosts
ALTER TABLE post_boosts ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
    DROP POLICY IF EXISTS "post_boosts_select" ON post_boosts;
    DROP POLICY IF EXISTS "post_boosts_insert" ON post_boosts;
EXCEPTION WHEN OTHERS THEN NULL;
END $$;

CREATE POLICY "post_boosts_select" ON post_boosts FOR SELECT USING (true);
CREATE POLICY "post_boosts_insert" ON post_boosts FOR INSERT WITH CHECK (auth.uid() IS NOT NULL);

-- 4. Create owner_transactions view (all payments for monitoring)
CREATE OR REPLACE VIEW owner_payments_view AS
SELECT 
    p.*,
    u.username as user_username,
    u.display_name as user_display_name,
    u.avatar as user_avatar,
    c.username as creator_username,
    c.display_name as creator_display_name
FROM payments p
LEFT JOIN profiles u ON p.user_id = u.id
LEFT JOIN profiles c ON p.creator_id = c.id
ORDER BY p.created_at DESC;

-- 5. Create owner_subscriptions view
CREATE OR REPLACE VIEW owner_subscriptions_view AS
SELECT 
    s.*,
    sub.username as subscriber_username,
    sub.display_name as subscriber_display_name,
    sub.avatar as subscriber_avatar,
    cr.username as creator_username,
    cr.display_name as creator_display_name
FROM subscriptions s
LEFT JOIN profiles sub ON s.subscriber_id = sub.id
LEFT JOIN profiles cr ON s.creator_id = cr.id
ORDER BY s.created_at DESC;

-- 6. Enable realtime for post_boosts
DO $$ BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE post_boosts;
EXCEPTION WHEN OTHERS THEN
    RAISE NOTICE 'Note: Could not add post_boosts to realtime: %', SQLERRM;
END $$;

SELECT 'Owner dashboard update complete!' AS status;
