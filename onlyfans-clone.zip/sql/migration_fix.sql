-- ============================================================
-- DEFINITIVE SCHEMA FIX - Only ALTER TABLE, no CREATE TABLE
-- Adds missing columns with IF NOT EXISTS safety
-- Forces PostgREST schema cache refresh
-- Run this in Supabase SQL Editor
-- ============================================================

-- ============================================================
-- 1. NOTIFICATIONS TABLE - Add missing columns
-- ============================================================
ALTER TABLE notifications ADD COLUMN IF NOT EXISTS related_id TEXT DEFAULT '';
ALTER TABLE notifications ADD COLUMN IF NOT EXISTS related_type TEXT DEFAULT '';
ALTER TABLE notifications ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT NOW();

-- ============================================================
-- 2. VIP_PURCHASES TABLE - Add missing columns
-- ============================================================
ALTER TABLE vip_purchases ADD COLUMN IF NOT EXISTS expires_at TIMESTAMPTZ;
ALTER TABLE vip_purchases ADD COLUMN IF NOT EXISTS approved_at TIMESTAMPTZ;
ALTER TABLE vip_purchases ADD COLUMN IF NOT EXISTS payment_method TEXT DEFAULT '';
ALTER TABLE vip_purchases ADD COLUMN IF NOT EXISTS declined_at TIMESTAMPTZ;
ALTER TABLE vip_purchases ADD COLUMN IF NOT EXISTS decline_reason TEXT DEFAULT '';
ALTER TABLE vip_purchases ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT NOW();

-- Also extend status check constraint to include 'expired' and 'disabled'
-- (safe: recreate constraint only if old one exists)
DO $$
BEGIN
    -- Try to drop old constraint if it exists
    ALTER TABLE vip_purchases DROP CONSTRAINT IF EXISTS vip_purchases_status_check;
    -- Add new constraint with all valid statuses
    ALTER TABLE vip_purchases ADD CONSTRAINT vip_purchases_status_check 
        CHECK (status IN ('pending', 'approved', 'rejected', 'expired', 'disabled'));
EXCEPTION WHEN OTHERS THEN
    -- If constraint already covers these, ignore
    NULL;
END $$;

-- ============================================================
-- 3. POSTS TABLE - Add missing columns
-- ============================================================
ALTER TABLE posts ADD COLUMN IF NOT EXISTS boosted_likes INTEGER DEFAULT 0;

-- ============================================================
-- 4. PROFILES TABLE - Add missing columns
-- ============================================================
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS likes_count INTEGER DEFAULT 0;

-- ============================================================
-- 5. PAYMENTS TABLE - Add missing columns (gift card images)
-- ============================================================
ALTER TABLE payments ADD COLUMN IF NOT EXISTS gc_front_url TEXT DEFAULT '';
ALTER TABLE payments ADD COLUMN IF NOT EXISTS gc_back_url TEXT DEFAULT '';

-- ============================================================
-- 6. CREATOR_PAYMENT_SETTINGS - Add missing QR columns
-- ============================================================
ALTER TABLE creator_payment_settings ADD COLUMN IF NOT EXISTS btc_qr_url TEXT DEFAULT '';
ALTER TABLE creator_payment_settings ADD COLUMN IF NOT EXISTS usdt_qr_url TEXT DEFAULT '';

-- ============================================================
-- 7. NOTIFICATIONS RLS POLICIES (safe recreation)
-- ============================================================
-- Enable RLS (safe if already enabled)
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

-- Drop and recreate policies (avoids "already exists" errors)
DROP POLICY IF EXISTS "notifs_select_own" ON notifications;
DROP POLICY IF EXISTS "notifs_insert_system" ON notifications;
DROP POLICY IF EXISTS "notifs_update_own" ON notifications;
DROP POLICY IF EXISTS "notifs_delete_own" ON notifications;

CREATE POLICY "notifs_select_own" ON notifications FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "notifs_insert_system" ON notifications FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY "notifs_update_own" ON notifications FOR UPDATE TO authenticated USING (user_id = auth.uid());
CREATE POLICY "notifs_delete_own" ON notifications FOR DELETE TO authenticated USING (user_id = auth.uid());

-- ============================================================
-- 8. CREATE/TRIGGER FUNCTIONS
-- ============================================================

-- Function: Auto-update profile likes_count when post_likes changes
CREATE OR REPLACE FUNCTION update_profile_likes_count()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        UPDATE profiles SET likes_count = COALESCE(likes_count, 0) + 1 
        WHERE id = (SELECT creator_id FROM posts WHERE id = NEW.post_id);
        RETURN NEW;
    ELSIF TG_OP = 'DELETE' THEN
        UPDATE profiles SET likes_count = GREATEST(COALESCE(likes_count, 0) - 1, 0) 
        WHERE id = (SELECT creator_id FROM posts WHERE id = OLD.post_id);
        RETURN OLD;
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Drop and recreate trigger
DROP TRIGGER IF EXISTS trg_update_profile_likes ON post_likes;
CREATE TRIGGER trg_update_profile_likes
AFTER INSERT OR DELETE ON post_likes
FOR EACH ROW
EXECUTE FUNCTION update_profile_likes_count();

-- Function: Expire VIP purchases after 2 days
CREATE OR REPLACE FUNCTION expire_vip_purchases()
RETURNS void AS $$
BEGIN
    UPDATE vip_purchases 
    SET status = 'expired'
    WHERE status = 'approved' 
    AND approved_at IS NOT NULL
    AND NOW() > (approved_at + INTERVAL '2 days');
END;
$$ LANGUAGE plpgsql;

-- Function: Expire old subscriptions
CREATE OR REPLACE FUNCTION expire_old_subscriptions()
RETURNS void AS $$
BEGIN
    UPDATE subscriptions 
    SET status = 'expired'
    WHERE status = 'approved'
    AND expires_at IS NOT NULL
    AND NOW() > expires_at;
END;
$$ LANGUAGE plpgsql;

-- Function: Expire verified badges after 30 days
CREATE OR REPLACE FUNCTION expire_verified_badges()
RETURNS void AS $$
BEGIN
    UPDATE verified_badge_subs 
    SET status = 'expired'
    WHERE status = 'active'
    AND expires_at IS NOT NULL
    AND NOW() > expires_at;
    
    -- Also unverify profiles
    UPDATE profiles 
    SET verified = FALSE 
    WHERE id IN (
        SELECT creator_id FROM verified_badge_subs 
        WHERE status = 'expired' AND verified = TRUE
    );
END;
$$ LANGUAGE plpgsql;

-- Function: Mark messages as read (bypasses RLS for read marking)
CREATE OR REPLACE FUNCTION mark_messages_read(p_room_id UUID, p_user_id UUID)
RETURNS void AS $$
BEGIN
    UPDATE messages 
    SET is_read = TRUE 
    WHERE room_id = p_room_id 
    AND sender_id != p_user_id 
    AND is_read = FALSE;
END;
$$ LANGUAGE plpgsql;

-- ============================================================
-- 9. INDEXES (safe - only creates if not exists)
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_unread ON notifications(user_id, is_read);
CREATE INDEX IF NOT EXISTS idx_vip_purchases_buyer ON vip_purchases(buyer_id);
CREATE INDEX IF NOT EXISTS idx_vip_purchases_video ON vip_purchases(video_id);
CREATE INDEX IF NOT EXISTS idx_vip_purchases_status ON vip_purchases(status);
CREATE INDEX IF NOT EXISTS idx_posts_boosted ON posts(boosted_likes);
CREATE INDEX IF NOT EXISTS idx_profiles_likes ON profiles(likes_count);

-- ============================================================
-- 10. FORCE SCHEMA CACHE REFRESH
-- PostgREST caches the schema. We need to invalidate it.
-- ============================================================

-- Method 1: NOTIFY (works on Supabase)
NOTIFY pgrst, 'reload schema';

-- Method 2: Dummy comment on tables (forces cache invalidation)
-- NOTE: Use simple strings only, no concatenation in COMMENT ON
COMMENT ON TABLE notifications IS 'notifications-v2-refreshed';
COMMENT ON TABLE vip_purchases IS 'vip_purchases-v2-refreshed';
COMMENT ON TABLE posts IS 'posts-v2-refreshed';
COMMENT ON TABLE profiles IS 'profiles-v2-refreshed';

SELECT 'Schema migration complete! All missing columns added. Please wait 10-30 seconds for schema cache to refresh, then refresh the page.' AS status;
