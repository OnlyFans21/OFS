-- ============================================================
-- FIX: Add missing columns that weren't in the original migration
-- Run this in Supabase SQL Editor
-- ============================================================

-- 1. Add missing columns to notifications table (if they don't exist)
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='notifications' AND column_name='related_id') THEN
        ALTER TABLE notifications ADD COLUMN related_id TEXT DEFAULT '';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='notifications' AND column_name='related_type') THEN
        ALTER TABLE notifications ADD COLUMN related_type TEXT DEFAULT '';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='notifications' AND column_name='updated_at') THEN
        ALTER TABLE notifications ADD COLUMN updated_at TIMESTAMPTZ DEFAULT now();
    END IF;
END $$;

-- 2. Add missing columns to vip_purchases table (if they don't exist)
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='vip_purchases' AND column_name='expires_at') THEN
        ALTER TABLE vip_purchases ADD COLUMN expires_at TIMESTAMPTZ;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='vip_purchases' AND column_name='approved_at') THEN
        ALTER TABLE vip_purchases ADD COLUMN approved_at TIMESTAMPTZ;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='vip_purchases' AND column_name='payment_method') THEN
        ALTER TABLE vip_purchases ADD COLUMN payment_method TEXT DEFAULT '';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='vip_purchases' AND column_name='declined_at') THEN
        ALTER TABLE vip_purchases ADD COLUMN declined_at TIMESTAMPTZ;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='vip_purchases' AND column_name='decline_reason') THEN
        ALTER TABLE vip_purchases ADD COLUMN decline_reason TEXT DEFAULT '';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='vip_purchases' AND column_name='updated_at') THEN
        ALTER TABLE vip_purchases ADD COLUMN updated_at TIMESTAMPTZ DEFAULT now();
    END IF;
END $$;

-- 3. Add missing columns to posts table
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='posts' AND column_name='boosted_likes') THEN
        ALTER TABLE posts ADD COLUMN boosted_likes INTEGER DEFAULT 0;
    END IF;
END $$;

-- 4. Add missing columns to profiles table
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='profiles' AND column_name='likes_count') THEN
        ALTER TABLE profiles ADD COLUMN likes_count INTEGER DEFAULT 0;
    END IF;
END $$;

-- 5. Create the likes trigger function
CREATE OR REPLACE FUNCTION update_profile_likes_count()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        UPDATE profiles SET likes_count = COALESCE(likes_count, 0) + 1 WHERE id = (
            SELECT creator_id FROM posts WHERE id = NEW.post_id
        );
        RETURN NEW;
    ELSIF TG_OP = 'DELETE' THEN
        UPDATE profiles SET likes_count = GREATEST(COALESCE(likes_count, 0) - 1, 0) WHERE id = (
            SELECT creator_id FROM posts WHERE id = OLD.post_id
        );
        RETURN OLD;
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- 6. Create the trigger
DROP TRIGGER IF EXISTS trg_update_profile_likes ON post_likes;
CREATE TRIGGER trg_update_profile_likes
AFTER INSERT OR DELETE ON post_likes
FOR EACH ROW
EXECUTE FUNCTION update_profile_likes_count();

-- 7. Create VIP expiry function
CREATE OR REPLACE FUNCTION expire_vip_purchases()
RETURNS void AS $$
BEGIN
    UPDATE vip_purchases 
    SET status = 'expired', updated_at = now()
    WHERE status = 'approved' 
    AND approved_at IS NOT NULL
    AND now() > (approved_at + interval '2 days');
END;
$$ LANGUAGE plpgsql;

-- 8. Force Supabase schema cache refresh
-- This invalidates the PostgREST schema cache so new columns are recognized
ALTER TABLE notifications ADD COLUMN IF NOT EXISTS _schema_refresh_col INT;
ALTER TABLE notifications DROP COLUMN IF EXISTS _schema_refresh_col;

ALTER TABLE vip_purchases ADD COLUMN IF NOT EXISTS _schema_refresh_col INT;
ALTER TABLE vip_purchases DROP COLUMN IF EXISTS _schema_refresh_col;

-- Also try NOTIFY approach
NOTIFY pgrst, 'reload schema';

-- 9. Create indexes
CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_unread ON notifications(user_id, is_read);
CREATE INDEX IF NOT EXISTS idx_vip_purchases_buyer ON vip_purchases(buyer_id);
CREATE INDEX IF NOT EXISTS idx_vip_purchases_video ON vip_purchases(video_id);
CREATE INDEX IF NOT EXISTS idx_vip_purchases_status ON vip_purchases(status);

SELECT 'All missing columns added and schema cache refreshed!' AS status;
