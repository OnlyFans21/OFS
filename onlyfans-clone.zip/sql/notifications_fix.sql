-- ============================================================
-- NOTIFICATION SYSTEM FIX
-- Fixes CHECK constraint and RLS policies
-- Safe to run multiple times
-- ============================================================

-- ============================================================
-- 1. FIX CHECK CONSTRAINT ON notifications.type
-- The base migration only allowed: 'like', 'comment', 'message', 'subscription', 'tip', 'follow', 'system'
-- The code uses: 'welcome', 'post', 'vip', 'payment_received', 'payment_approved', 
--                'payment_declined', 'subscription_expiry', 'vip_expiry', 'message', 'general'
-- ============================================================

-- Step 1a: Drop the old restrictive CHECK constraint
ALTER TABLE notifications DROP CONSTRAINT IF EXISTS notifications_type_check;

-- Step 1b: Add new CHECK constraint with ALL types used by the application
ALTER TABLE notifications ADD CONSTRAINT notifications_type_check
    CHECK (type IN (
        'welcome',           -- New user signup
        'post',              -- Creator posted new content
        'vip',               -- Creator uploaded VIP video
        'payment_received',  -- Creator receives payment request
        'payment_approved',  -- Fan's payment was approved
        'payment_declined',  -- Fan's payment was declined
        'message',           -- New chat message
        'subscription_expiry', -- Subscription expiring/expired
        'vip_expiry',        -- VIP access expiring
        'like',              -- Post liked (legacy)
        'comment',           -- Post commented (legacy)
        'tip',               -- Tip received (legacy)
        'follow',            -- New follower (legacy)
        'system',            -- System announcement (legacy)
        'general'            -- Fallback type
    ));

-- ============================================================
-- 2. FIX RLS POLICIES
-- Problem: INSERT policy was changed to (user_id = auth.uid())
-- But code creates notifications FOR other users (e.g., creator
-- approves payment → notifies the fan). So auth.uid() ≠ user_id.
-- Solution: INSERT must be WITH CHECK (true) - app logic controls who
-- gets notified. SELECT/UPDATE/DELETE stay restricted to own notifs.
-- ============================================================

-- Drop ALL existing notification policies (clean slate)
DROP POLICY IF EXISTS "notifs_select" ON notifications;
DROP POLICY IF EXISTS "notifs_insert" ON notifications;
DROP POLICY IF EXISTS "notifs_update" ON notifications;
DROP POLICY IF EXISTS "notifs_delete" ON notifications;
DROP POLICY IF EXISTS "notifs_select_own" ON notifications;
DROP POLICY IF EXISTS "notifs_insert_system" ON notifications;
DROP POLICY IF EXISTS "notifs_update_own" ON notifications;
DROP POLICY IF EXISTS "notifs_delete_own" ON notifications;

-- Enable RLS (safe if already enabled)
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

-- SELECT: Users can only read their own notifications
CREATE POLICY "notifs_select_own" ON notifications
    FOR SELECT TO authenticated
    USING (user_id = auth.uid());

-- INSERT: WITH CHECK (true) - Application logic controls recipient
-- The app only sends notifications to the correct users, so this is safe.
-- Restricting to (user_id = auth.uid()) breaks cross-user notifications
-- like "creator approves payment → notify fan".
CREATE POLICY "notifs_insert" ON notifications
    FOR INSERT TO authenticated
    WITH CHECK (true);

-- UPDATE: Users can only mark their own notifications as read
CREATE POLICY "notifs_update_own" ON notifications
    FOR UPDATE TO authenticated
    USING (user_id = auth.uid());

-- DELETE: Users can only delete their own notifications
CREATE POLICY "notifs_delete_own" ON notifications
    FOR DELETE TO authenticated
    USING (user_id = auth.uid());

-- ============================================================
-- 3. VERIFY
-- ============================================================

-- Show the new constraint
SELECT conname, pg_get_constraintdef(oid) as constraint_def
FROM pg_constraint
WHERE conrelid = 'notifications'::regclass
AND conname = 'notifications_type_check';

-- Show all policies
SELECT policyname, permissive, roles, cmd, qual, with_check
FROM pg_policies
WHERE tablename = 'notifications';

SELECT 'Notification system fixed!' AS status;
