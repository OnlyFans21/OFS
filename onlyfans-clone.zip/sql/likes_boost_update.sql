-- ============================================================
-- POST LIKES & OWNER BOOST SYSTEM UPDATE
-- Run this AFTER migration.sql, rls_policies.sql, storage_policies.sql
-- ============================================================

-- ============================================================
-- 1. ADD boosted_likes COLUMN TO posts TABLE
-- ============================================================

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='posts' AND column_name='boosted_likes') THEN
        ALTER TABLE posts ADD COLUMN boosted_likes INTEGER DEFAULT 0;
    END IF;
END $$;

-- ============================================================
-- 2. CREATE boost_history TABLE
-- ============================================================

CREATE TABLE IF NOT EXISTS boost_history (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    post_id UUID NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
    owner_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    previous_count INTEGER NOT NULL DEFAULT 0,
    likes_added INTEGER NOT NULL DEFAULT 0,
    new_total INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_boost_history_post ON boost_history(post_id);
CREATE INDEX IF NOT EXISTS idx_boost_history_owner ON boost_history(owner_id);
CREATE INDEX IF NOT EXISTS idx_boost_history_created ON boost_history(created_at DESC);

-- ============================================================
-- 3. RLS POLICIES FOR boost_history
-- ============================================================

ALTER TABLE boost_history ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "boost_history_select" ON boost_history;
DROP POLICY IF EXISTS "boost_history_insert" ON boost_history;
DROP POLICY IF EXISTS "boost_history_delete" ON boost_history;

-- Only authenticated users can view boost history (owner checks in app)
CREATE POLICY "boost_history_select" ON boost_history FOR SELECT TO authenticated USING (true);

-- Only authenticated users can insert (owner checks in app)
CREATE POLICY "boost_history_insert" ON boost_history FOR INSERT TO authenticated WITH CHECK (true);

-- Only authenticated users can delete (owner checks in app)
CREATE POLICY "boost_history_delete" ON boost_history FOR DELETE TO authenticated USING (true);

-- ============================================================
-- 4. REALTIME FOR post_likes AND boost_history
-- ============================================================

ALTER PUBLICATION supabase_realtime ADD TABLE post_likes;
ALTER PUBLICATION supabase_realtime ADD TABLE boost_history;

-- ============================================================
-- 5. HELPER FUNCTION: Get total like count for a post (real + boosted)
-- ============================================================

CREATE OR REPLACE FUNCTION get_post_like_count(p_post_id UUID)
RETURNS INTEGER AS $$
DECLARE
    v_real_likes INTEGER;
    v_boosted INTEGER;
BEGIN
    SELECT COUNT(*) INTO v_real_likes FROM post_likes WHERE post_id = p_post_id;
    SELECT COALESCE(boosted_likes, 0) INTO v_boosted FROM posts WHERE id = p_post_id;
    RETURN v_real_likes + v_boosted;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================================
-- 6. HELPER FUNCTION: Get creator like analytics
-- ============================================================

CREATE OR REPLACE FUNCTION get_creator_like_analytics(p_creator_id UUID)
RETURNS TABLE (
    total_likes BIGINT,
    total_boosted BIGINT,
    most_liked_post_id UUID,
    most_liked_count BIGINT
) AS $$
BEGIN
    RETURN QUERY
    SELECT
        COALESCE(SUM((SELECT COUNT(*) FROM post_likes WHERE post_id = p.id)), 0)::BIGINT as total_likes,
        COALESCE(SUM(p.boosted_likes), 0)::BIGINT as total_boosted,
        (SELECT p2.id FROM posts p2 WHERE p2.creator_id = p_creator_id ORDER BY ((SELECT COUNT(*) FROM post_likes pl WHERE pl.post_id = p2.id) + p2.boosted_likes) DESC LIMIT 1) as most_liked_post_id,
        (SELECT COALESCE((SELECT COUNT(*) FROM post_likes WHERE post_id = (SELECT p3.id FROM posts p3 WHERE p3.creator_id = p_creator_id ORDER BY ((SELECT COUNT(*) FROM post_likes pl2 WHERE pl2.post_id = p3.id) + p3.boosted_likes) DESC LIMIT 1)), 0) + COALESCE((SELECT boosted_likes FROM posts WHERE id = (SELECT p4.id FROM posts p4 WHERE p4.creator_id = p_creator_id ORDER BY ((SELECT COUNT(*) FROM post_likes pl3 WHERE pl3.post_id = p4.id) + p4.boosted_likes) DESC LIMIT 1)), 0))::BIGINT as most_liked_count
    FROM posts p
    WHERE p.creator_id = p_creator_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

SELECT 'Likes & Boost system update completed!' AS status;
