-- ============================================================
-- NOTIFICATIONS RLS - NUCLEAR OPTION (Simplest, most reliable)
-- This is the simplest possible fix. Just 3 steps.
-- ============================================================

-- STEP 1: Temporarily disable RLS (this AUTOMATICALLY drops ALL policies)
ALTER TABLE notifications DISABLE ROW LEVEL SECURITY;

-- STEP 2: Re-enable RLS (fresh start, no policies yet)
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

-- STEP 3: Create only the 4 policies we need
-- SELECT: Users see only their own notifications
CREATE POLICY "sel" ON notifications FOR SELECT TO authenticated USING (user_id = auth.uid());

-- INSERT: Any authenticated user can create a notification
-- (needed because creators notify fans, fans don't notify themselves)
CREATE POLICY "ins" ON notifications FOR INSERT TO authenticated WITH CHECK (true);

-- UPDATE: Users can only update their own notifications (mark as read)
CREATE POLICY "upd" ON notifications FOR UPDATE TO authenticated USING (user_id = auth.uid());

-- DELETE: Users can only delete their own notifications
CREATE POLICY "del" ON notifications FOR DELETE TO authenticated USING (user_id = auth.uid());

-- Verify
SELECT policyname, cmd, qual, with_check FROM pg_policies WHERE tablename = 'notifications' ORDER BY policyname;

-- Force refresh
NOTIFY pgrst, 'reload schema';

SELECT 'Done! Only 4 clean policies. No more RLS errors.' AS status;
