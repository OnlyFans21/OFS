-- ============================================================
-- ONLYFANS CLONE - PAYMENT & SUBSCRIPTION SYSTEM UPDATE
-- Run this in Supabase SQL Editor AFTER the main migration
-- Safe to run multiple times (uses IF NOT EXISTS)
-- ============================================================

-- 1. Add subscription_status to subscriptions (for disable/enable)
DO $$ BEGIN
    ALTER TABLE subscriptions ADD COLUMN IF NOT EXISTS subscription_status TEXT DEFAULT 'active' CHECK (subscription_status IN ('active', 'disabled', 'pending'));
EXCEPTION WHEN OTHERS THEN
    RAISE NOTICE 'Note: subscription_status: %', SQLERRM;
END $$;

-- 2. Add expires_at if missing
DO $$ BEGIN
    ALTER TABLE subscriptions ADD COLUMN IF NOT EXISTS expires_at TIMESTAMPTZ;
EXCEPTION WHEN OTHERS THEN
    RAISE NOTICE 'Note: expires_at: %', SQLERRM;
END $$;

-- 3. Enable realtime for payments (instant creator notifications)
DO $$ BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE payments;
EXCEPTION WHEN OTHERS THEN
    RAISE NOTICE 'Note: payments realtime: %', SQLERRM;
END $$;

-- 4. Enable realtime for subscriptions
DO $$ BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE subscriptions;
EXCEPTION WHEN OTHERS THEN
    RAISE NOTICE 'Note: subscriptions realtime: %', SQLERRM;
END $$;

-- 5. RLS for payments - ensure creators can see payments sent to them
DO $$ BEGIN
    DROP POLICY IF EXISTS "payments_creator_select" ON payments;
END $$;
CREATE POLICY "payments_creator_select" ON payments FOR SELECT USING (auth.uid() = user_id OR auth.uid() = creator_id);

-- 6. Function to auto-create subscription on payment approval
CREATE OR REPLACE FUNCTION public.approve_payment_and_subscribe()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.status = 'approved' AND OLD.status = 'pending' THEN
        INSERT INTO public.subscriptions (subscriber_id, creator_id, plan_type, amount, status, expires_at, subscription_status)
        VALUES (NEW.user_id, NEW.creator_id, NEW.payment_type, NEW.amount, 'approved', NOW() + INTERVAL '30 days', 'active')
        ON CONFLICT (subscriber_id, creator_id)
        DO UPDATE SET
            status = 'approved',
            expires_at = NOW() + INTERVAL '30 days',
            subscription_status = 'active',
            updated_at = NOW();
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 7. Trigger on payments table
DROP TRIGGER IF EXISTS tr_payment_approved ON payments;
CREATE TRIGGER tr_payment_approved
    AFTER UPDATE OF status ON payments
    FOR EACH ROW
    WHEN (NEW.status = 'approved' AND OLD.status = 'pending')
    EXECUTE FUNCTION public.approve_payment_and_subscribe();

-- 8. Helper function: Disable expired subscriptions
CREATE OR REPLACE FUNCTION public.disable_expired_subscriptions()
RETURNS void AS $$
BEGIN
    UPDATE subscriptions
    SET subscription_status = 'disabled'
    WHERE expires_at IS NOT NULL
      AND expires_at < NOW()
      AND subscription_status = 'active';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Run it once now
SELECT public.disable_expired_subscriptions();

SELECT 'Payment & Subscription system update completed!' AS status;
