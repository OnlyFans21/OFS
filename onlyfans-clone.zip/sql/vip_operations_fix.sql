-- ============================================================
-- VIP OPERATIONS - Bulletproof RPC Functions
-- SECURITY DEFINER bypasses all RLS and schema cache issues
-- ============================================================

-- 1. Ensure vip_purchases has all needed columns
ALTER TABLE vip_purchases ADD COLUMN IF NOT EXISTS expires_at TIMESTAMPTZ;
ALTER TABLE vip_purchases ADD COLUMN IF NOT EXISTS approved_at TIMESTAMPTZ;
ALTER TABLE vip_purchases ADD COLUMN IF NOT EXISTS payment_method TEXT DEFAULT '';
ALTER TABLE vip_purchases ADD COLUMN IF NOT EXISTS declined_at TIMESTAMPTZ;
ALTER TABLE vip_purchases ADD COLUMN IF NOT EXISTS decline_reason TEXT DEFAULT '';

-- 2. Approve a VIP purchase (sets approved_at + expires_at = now + 2 days)
CREATE OR REPLACE FUNCTION approve_vip_purchase(p_purchase_id UUID)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    UPDATE vip_purchases 
    SET status = 'approved',
        approved_at = NOW(),
        expires_at = NOW() + INTERVAL '2 days'
    WHERE id = p_purchase_id;
    RETURN FOUND;
END;
$$;

-- 3. Decline a VIP purchase
CREATE OR REPLACE FUNCTION decline_vip_purchase(p_purchase_id UUID, p_reason TEXT DEFAULT '')
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    UPDATE vip_purchases 
    SET status = 'declined',
        declined_at = NOW(),
        decline_reason = p_reason
    WHERE id = p_purchase_id;
    RETURN FOUND;
END;
$$;

-- 4. Disable a VIP purchase
CREATE OR REPLACE FUNCTION disable_vip_purchase(p_purchase_id UUID)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    UPDATE vip_purchases 
    SET status = 'disabled'
    WHERE id = p_purchase_id;
    RETURN FOUND;
END;
$$;

-- 5. Remove (delete) a VIP purchase
CREATE OR REPLACE FUNCTION remove_vip_purchase(p_purchase_id UUID)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    DELETE FROM vip_purchases WHERE id = p_purchase_id;
    RETURN FOUND;
END;
$$;

-- 6. Get creator's VIP purchases with fan profiles (returns JSON)
CREATE OR REPLACE FUNCTION get_creator_vip_purchases(p_creator_id UUID)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    result JSON;
BEGIN
    SELECT json_agg(
        json_build_object(
            'id', vp.id,
            'buyer_id', vp.buyer_id,
            'video_id', vp.video_id,
            'amount', vp.amount,
            'status', vp.status,
            'payment_method', vp.payment_method,
            'created_at', vp.created_at,
            'approved_at', vp.approved_at,
            'expires_at', vp.expires_at,
            'declined_at', vp.declined_at,
            'decline_reason', vp.decline_reason,
            'buyer', json_build_object(
                'id', p.id,
                'username', p.username,
                'display_name', p.display_name,
                'avatar', p.avatar
            ),
            'video', json_build_object(
                'id', vv.id,
                'title', vv.title,
                'price', vv.price,
                'video_url', vv.video_url,
                'creator_id', vv.creator_id
            )
        ) ORDER BY vp.created_at DESC
    )
    INTO result
    FROM vip_purchases vp
    JOIN profiles p ON p.id = vp.buyer_id
    JOIN vip_videos vv ON vv.id = vp.video_id
    WHERE vv.creator_id = p_creator_id;
    
    RETURN COALESCE(result, '[]'::json);
END;
$$;

-- 7. Grant execute to all users
GRANT EXECUTE ON FUNCTION approve_vip_purchase(UUID) TO authenticated, anon;
GRANT EXECUTE ON FUNCTION decline_vip_purchase(UUID, TEXT) TO authenticated, anon;
GRANT EXECUTE ON FUNCTION disable_vip_purchase(UUID) TO authenticated, anon;
GRANT EXECUTE ON FUNCTION remove_vip_purchase(UUID) TO authenticated, anon;
GRANT EXECUTE ON FUNCTION get_creator_vip_purchases(UUID) TO authenticated, anon;

-- 8. Also ensure the notification RPC exists
CREATE OR REPLACE FUNCTION create_notification(
    p_user_id UUID,
    p_type TEXT,
    p_title TEXT,
    p_body TEXT DEFAULT '',
    p_related_id TEXT DEFAULT '',
    p_related_type TEXT DEFAULT ''
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE new_id UUID;
BEGIN
    INSERT INTO notifications (user_id, type, title, body, related_id, related_type)
    VALUES (p_user_id, p_type, p_title, p_body, p_related_id, p_related_type)
    RETURNING id INTO new_id;
    RETURN new_id;
END;
$$;

GRANT EXECUTE ON FUNCTION create_notification(UUID, TEXT, TEXT, TEXT, TEXT, TEXT) TO authenticated, anon;

-- 9. Clean up notification RLS (keep only select/update/delete)
DO $$ DECLARE pol RECORD; BEGIN
    FOR pol IN SELECT policyname FROM pg_policies WHERE tablename = 'notifications'
    LOOP EXECUTE format('DROP POLICY IF EXISTS %I ON notifications', pol.policyname); END LOOP;
END $$;

ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
CREATE POLICY "n_sel" ON notifications FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "n_upd" ON notifications FOR UPDATE TO authenticated USING (user_id = auth.uid());
CREATE POLICY "n_del" ON notifications FOR DELETE TO authenticated USING (user_id = auth.uid());

-- 10. Refresh
NOTIFY pgrst, 'reload schema';

SELECT 'All VIP operations + notifications now use bulletproof RPC functions.' AS status;
