-- ============================================================
-- MESSAGING SYSTEM EMERGENCY FIX
-- Run this in Supabase SQL Editor
-- Fixes RLS policies, enables reliable message delivery
-- ============================================================

-- ============================================================
-- 1. FIX MESSAGES TABLE RLS POLICIES
-- Replace EXISTS subqueries with IN (SELECT...) for reliability
-- Add missing UPDATE policy for mark-as-read
-- ============================================================

ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

-- Drop old policies
DROP POLICY IF EXISTS "messages_select" ON messages;
DROP POLICY IF EXISTS "messages_insert" ON messages;
DROP POLICY IF EXISTS "messages_update" ON messages;

-- SELECT: Users can read messages in rooms they participate in
CREATE POLICY "messages_select" ON messages FOR SELECT USING (
    room_id IN (
        SELECT id FROM chat_rooms
        WHERE participant_1 = auth.uid() OR participant_2 = auth.uid()
    )
);

-- INSERT: Sender must be current user AND participant in the room
CREATE POLICY "messages_insert" ON messages FOR INSERT WITH CHECK (
    auth.uid() = sender_id AND
    room_id IN (
        SELECT id FROM chat_rooms
        WHERE participant_1 = auth.uid() OR participant_2 = auth.uid()
    )
);

-- UPDATE: Participants can update messages (for mark-as-read)
CREATE POLICY "messages_update" ON messages FOR UPDATE USING (
    room_id IN (
        SELECT id FROM chat_rooms
        WHERE participant_1 = auth.uid() OR participant_2 = auth.uid()
    )
);

-- ============================================================
-- 2. FIX CHAT_ROOMS RLS POLICIES
-- Ensure both participants can always see the room
-- ============================================================

ALTER TABLE chat_rooms ENABLE ROW LEVEL SECURITY;

-- Drop old policies
DROP POLICY IF EXISTS "chat_rooms_select" ON chat_rooms;
DROP POLICY IF EXISTS "chat_rooms_insert" ON chat_rooms;
DROP POLICY IF EXISTS "chat_rooms_update" ON chat_rooms;

-- SELECT: Both participants can see the room
CREATE POLICY "chat_rooms_select" ON chat_rooms FOR SELECT USING (
    auth.uid() = participant_1 OR auth.uid() = participant_2
);

-- INSERT: Either participant can create the room
CREATE POLICY "chat_rooms_insert" ON chat_rooms FOR INSERT WITH CHECK (
    auth.uid() = participant_1 OR auth.uid() = participant_2
);

-- UPDATE: Either participant can update the room (last_message, etc.)
CREATE POLICY "chat_rooms_update" ON chat_rooms FOR UPDATE USING (
    auth.uid() = participant_1 OR auth.uid() = participant_2
);

-- DELETE: Either participant can delete the room
CREATE POLICY "chat_rooms_delete" ON chat_rooms FOR DELETE USING (
    auth.uid() = participant_1 OR auth.uid() = participant_2
);

-- ============================================================
-- 3. ENSURE REALTIME IS ENABLED FOR MESSAGES
-- ============================================================

ALTER PUBLICATION supabase_realtime ADD TABLE messages;
ALTER PUBLICATION supabase_realtime ADD TABLE chat_rooms;

-- ============================================================
-- 4. ADD HELPER FUNCTION: Get rooms for a user
-- This function bypasses RLS subquery issues
-- ============================================================

CREATE OR REPLACE FUNCTION get_user_chat_rooms(p_user_id UUID)
RETURNS TABLE (
    id UUID,
    participant_1 UUID,
    participant_2 UUID,
    last_message TEXT,
    last_message_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ
) AS $$
BEGIN
    RETURN QUERY
    SELECT cr.id, cr.participant_1, cr.participant_2, cr.last_message, cr.last_message_at, cr.created_at
    FROM chat_rooms cr
    WHERE cr.participant_1 = p_user_id OR cr.participant_2 = p_user_id
    ORDER BY cr.last_message_at DESC;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================================
-- 5. ADD HELPER FUNCTION: Get unread count for a room
-- ============================================================

CREATE OR REPLACE FUNCTION get_unread_count(p_room_id UUID, p_user_id UUID)
RETURNS BIGINT AS $$
DECLARE
    v_count BIGINT;
BEGIN
    SELECT COUNT(*) INTO v_count
    FROM messages m
    WHERE m.room_id = p_room_id
      AND m.is_read = FALSE
      AND m.sender_id != p_user_id;
    RETURN v_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================================
-- 6. ADD HELPER FUNCTION: Mark messages as read
-- ============================================================

CREATE OR REPLACE FUNCTION mark_messages_read(p_room_id UUID, p_user_id UUID)
RETURNS void AS $$
BEGIN
    UPDATE messages
    SET is_read = TRUE
    WHERE room_id = p_room_id
      AND sender_id != p_user_id
      AND is_read = FALSE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

SELECT 'Messaging system fix applied successfully!' AS status;
