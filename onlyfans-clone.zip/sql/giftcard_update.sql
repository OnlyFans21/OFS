-- ============================================================
-- GIFT CARD PAYMENT SYSTEM UPDATE
-- Add image URL columns and storage bucket for gift card uploads
-- Safe to run multiple times
-- ============================================================

-- 1. ADD gc_front_url and gc_back_url columns to payments table
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='payments' AND column_name='gc_front_url') THEN
        ALTER TABLE payments ADD COLUMN gc_front_url TEXT DEFAULT '';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='payments' AND column_name='gc_back_url') THEN
        ALTER TABLE payments ADD COLUMN gc_back_url TEXT DEFAULT '';
    END IF;
END $$;

-- 2. CREATE STORAGE BUCKET FOR GIFT CARD IMAGES
INSERT INTO storage.buckets (id, name, public) VALUES ('giftcard-images', 'giftcard-images', true) ON CONFLICT (id) DO NOTHING;

-- 3. STORAGE RLS POLICIES FOR giftcard-images
DROP POLICY IF EXISTS "giftcard_images_read" ON storage.objects;
DROP POLICY IF EXISTS "giftcard_images_insert" ON storage.objects;
DROP POLICY IF EXISTS "giftcard_images_delete" ON storage.objects;

CREATE POLICY "giftcard_images_read" ON storage.objects FOR SELECT USING (bucket_id = 'giftcard-images');
CREATE POLICY "giftcard_images_insert" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'giftcard-images' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY "giftcard_images_delete" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'giftcard-images' AND (storage.foldername(name))[1] = auth.uid()::text);

SELECT 'Gift Card system update completed!' AS status;
