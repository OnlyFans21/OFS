-- ============================================================
-- LIKES + ONLINE STATUS - Complete Fix
-- ============================================================

-- 1. Ensure posts.likes_count exists
ALTER TABLE posts ADD COLUMN IF NOT EXISTS likes_count INTEGER DEFAULT 0;

-- 2. Ensure profiles has likes_count, is_online, last_seen
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS likes_count INTEGER DEFAULT 0;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS is_online BOOLEAN DEFAULT FALSE;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS last_seen TIMESTAMPTZ;

-- 3. Sync posts.likes_count with actual post_likes count
UPDATE posts SET likes_count = (
    SELECT COUNT(*) FROM post_likes WHERE post_likes.post_id = posts.id
);

-- 4. Sync profiles.likes_count with total likes across all posts
UPDATE profiles SET likes_count = (
    SELECT COALESCE(SUM(posts.likes_count), 0) FROM posts WHERE posts.creator_id = profiles.id
);

-- 5. DROP old trigger (we'll handle likes_count via RPC)
DROP TRIGGER IF EXISTS trg_update_profile_likes ON post_likes;
DROP FUNCTION IF EXISTS update_profile_likes_count();

-- 6. RPC: Toggle like on a post (like or unlike)
-- Updates posts.likes_count and profiles.likes_count atomically
CREATE OR REPLACE FUNCTION toggle_post_like(p_post_id UUID, p_user_id UUID)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    existing_id UUID;
    creator_uid UUID;
    new_liked BOOLEAN;
    post_likes_now INTEGER;
BEGIN
    -- Get the creator_id for this post
    SELECT creator_id INTO creator_uid FROM posts WHERE id = p_post_id;
    IF creator_uid IS NULL THEN
        RETURN json_build_object('liked', false, 'likes_count', 0, 'error', 'Post not found');
    END IF;

    -- Check if already liked
    SELECT id INTO existing_id FROM post_likes WHERE post_id = p_post_id AND user_id = p_user_id;

    IF existing_id IS NOT NULL THEN
        -- Unlike: delete the like
        DELETE FROM post_likes WHERE id = existing_id;
        new_liked := false;
    ELSE
        -- Like: insert new like (ignore duplicate key)
        BEGIN
            INSERT INTO post_likes (post_id, user_id) VALUES (p_post_id, p_user_id);
        EXCEPTION WHEN unique_violation THEN
            -- Already liked somehow, treat as unlike
            DELETE FROM post_likes WHERE post_id = p_post_id AND user_id = p_user_id;
            new_liked := false;
            -- Recalculate
            SELECT COUNT(*) INTO post_likes_now FROM post_likes WHERE post_id = p_post_id;
            UPDATE posts SET likes_count = post_likes_now WHERE id = p_post_id;
            UPDATE profiles SET likes_count = (
                SELECT COALESCE(SUM(likes_count), 0) FROM posts WHERE creator_id = creator_uid
            ) WHERE id = creator_uid;
            RETURN json_build_object('liked', false, 'likes_count', post_likes_now);
        END;
        new_liked := true;
    END IF;

    -- Recalculate actual like count for this post
    SELECT COUNT(*) INTO post_likes_now FROM post_likes WHERE post_id = p_post_id;

    -- Update posts.likes_count
    UPDATE posts SET likes_count = post_likes_now WHERE id = p_post_id;

    -- Update profiles.likes_count (sum of all post likes for this creator)
    UPDATE profiles SET likes_count = (
        SELECT COALESCE(SUM(likes_count), 0) FROM posts WHERE creator_id = creator_uid
    ) WHERE id = creator_uid;

    RETURN json_build_object('liked', new_liked, 'likes_count', post_likes_now);
END;
$$;

-- 7. RPC: Boost likes on a post
CREATE OR REPLACE FUNCTION boost_post_likes(p_post_id UUID, p_boost_amount INTEGER)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    creator_uid UUID;
    old_boosted INTEGER;
    new_boosted INTEGER;
    post_likes_now INTEGER;
BEGIN
    -- Get creator and current boosted
    SELECT creator_id, COALESCE(boosted_likes, 0) INTO creator_uid, old_boosted
    FROM posts WHERE id = p_post_id;

    IF creator_uid IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Post not found');
    END IF;

    new_boosted := old_boosted + p_boost_amount;

    -- Update post boosted_likes
    UPDATE posts SET boosted_likes = new_boosted WHERE id = p_post_id;

    -- Get current real likes
    SELECT COUNT(*) INTO post_likes_now FROM post_likes WHERE post_id = p_post_id;

    -- Update posts.likes_count to match real count
    UPDATE posts SET likes_count = post_likes_now WHERE id = p_post_id;

    -- Update profiles.likes_count (real + boosted)
    UPDATE profiles SET likes_count = (
        SELECT COALESCE(SUM(likes_count + COALESCE(boosted_likes, 0)), 0)
        FROM posts WHERE creator_id = creator_uid
    ) WHERE id = creator_uid;

    RETURN json_build_object('success', true, 'boosted_likes', new_boosted, 'total_likes', post_likes_now + new_boosted);
END;
$$;

-- 8. RPC: Reset post boost
CREATE OR REPLACE FUNCTION reset_post_boost(p_post_id UUID)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    creator_uid UUID;
BEGIN
    SELECT creator_id INTO creator_uid FROM posts WHERE id = p_post_id;
    IF creator_uid IS NULL THEN RETURN false; END IF;

    UPDATE posts SET boosted_likes = 0 WHERE id = p_post_id;

    UPDATE profiles SET likes_count = (
        SELECT COALESCE(SUM(likes_count + COALESCE(boosted_likes, 0)), 0)
        FROM posts WHERE creator_id = creator_uid
    ) WHERE id = creator_uid;

    RETURN true;
END;
$$;

-- 9. RPC: Update user online status
CREATE OR REPLACE FUNCTION update_user_status(p_user_id UUID, p_is_online BOOLEAN)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    UPDATE profiles SET
        is_online = p_is_online,
        last_seen = CASE WHEN p_is_online THEN NOW() ELSE COALESCE(last_seen, NOW()) END
    WHERE id = p_user_id;
    RETURN FOUND;
END;
$$;

-- 10. RPC: Get users online status (batch)
CREATE OR REPLACE FUNCTION get_users_status(p_user_ids TEXT)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    result JSON;
BEGIN
    SELECT json_agg(json_build_object(
        'id', id,
        'is_online', is_online,
        'last_seen', last_seen
    ))
    INTO result
    FROM profiles
    WHERE id = ANY(string_to_array(p_user_ids, ',')::UUID[]);
    RETURN COALESCE(result, '[]'::json);
END;
$$;

-- 11. RPC: Get single user status
CREATE OR REPLACE FUNCTION get_user_status(p_user_id UUID)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    result JSON;
BEGIN
    SELECT json_build_object(
        'id', id,
        'is_online', is_online,
        'last_seen', last_seen
    )
    INTO result
    FROM profiles WHERE id = p_user_id;
    RETURN result;
END;
$$;

-- 12. Auto-mark offline after 2 minutes of inactivity
CREATE OR REPLACE FUNCTION mark_inactive_users_offline()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    UPDATE profiles SET
        is_online = false,
        last_seen = NOW()
    WHERE is_online = true
    AND last_seen < NOW() - INTERVAL '2 minutes';
END;
$$;

-- 13. Grant execute permissions
GRANT EXECUTE ON FUNCTION toggle_post_like(UUID, UUID) TO authenticated, anon;
GRANT EXECUTE ON FUNCTION boost_post_likes(UUID, INTEGER) TO authenticated, anon;
GRANT EXECUTE ON FUNCTION reset_post_boost(UUID) TO authenticated, anon;
GRANT EXECUTE ON FUNCTION update_user_status(UUID, BOOLEAN) TO authenticated, anon;
GRANT EXECUTE ON FUNCTION get_users_status(TEXT) TO authenticated, anon;
GRANT EXECUTE ON FUNCTION get_user_status(UUID) TO authenticated, anon;
GRANT EXECUTE ON FUNCTION mark_inactive_users_offline() TO authenticated, anon;

-- 14. Refresh
NOTIFY pgrst, 'reload schema';

SELECT 'Likes + Online Status fix complete.' AS status;
