-- ============================================================
-- NOTIFICATIONS FIX: PostgreSQL RPC Function
-- This bypasses RLS entirely by using SECURITY DEFINER
-- ============================================================

-- 1. First, drop ALL existing policies to clean up the mess
DO $$
DECLARE pol RECORD;
BEGIN
    FOR pol IN SELECT policyname FROM pg_policies WHERE tablename = 'notifications'
    LOOP
        EXECUTE format('DROP POLICY IF EXISTS %I ON notifications', pol.policyname);
    END LOOP;
END $$;

-- 2. Ensure table has correct columns
ALTER TABLE notifications ADD COLUMN IF NOT EXISTS related_id TEXT DEFAULT '';
ALTER TABLE notifications ADD COLUMN IF NOT EXISTS related_type TEXT DEFAULT '';
ALTER TABLE notifications ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT NOW();

-- 3. Update the CHECK constraint to allow all types used by the app
ALTER TABLE notifications DROP CONSTRAINT IF EXISTS notifications_type_check;
ALTER TABLE notifications ADD CONSTRAINT notifications_type_check
    CHECK (type IN (
        'welcome', 'post', 'vip', 'payment_received', 'payment_approved',
        'payment_declined', 'message', 'subscription_expiry', 'vip_expiry',
        'like', 'comment', 'tip', 'follow', 'system', 'general'
    ));

-- 4. Enable RLS
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

-- 5. Create simple policies for SELECT/UPDATE/DELETE (user's own notifs only)
CREATE POLICY "n_sel" ON notifications FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "n_upd" ON notifications FOR UPDATE TO authenticated USING (user_id = auth.uid());
CREATE POLICY "n_del" ON notifications FOR DELETE TO authenticated USING (user_id = auth.uid());

-- 6. Create the RPC function that bypasses RLS for INSERTS
-- SECURITY DEFINER means it runs as the table owner, bypassing RLS
CREATE OR REPLACE FUNCTION create_notification(
    p_user_id UUID,
    p_type TEXT,
    p_title TEXT,
    p_body TEXT DEFAULT '',
    p_related_id TEXT DEFAULT '',
    p_related_type TEXT DEFAULT ''
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    new_id UUID;
BEGIN
    -- Validate type against CHECK constraint
    IF p_type NOT IN (
        'welcome', 'post', 'vip', 'payment_received', 'payment_approved',
        'payment_declined', 'message', 'subscription_expiry', 'vip_expiry',
        'like', 'comment', 'tip', 'follow', 'system', 'general'
    ) THEN
        RAISE EXCEPTION 'Invalid notification type: %', p_type;
    END IF;

    INSERT INTO notifications (user_id, type, title, body, related_id, related_type)
    VALUES (p_user_id, p_type, p_title, p_body, p_related_id, p_related_type)
    RETURNING id INTO new_id;

    RETURN new_id;
END;
$$;

-- 7. Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION create_notification(UUID, TEXT, TEXT, TEXT, TEXT, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION create_notification(UUID, TEXT, TEXT, TEXT, TEXT, TEXT) TO anon;

-- 8. Verify
SELECT proname, prosecdef FROM pg_proc WHERE proname = 'create_notification';

-- 9. Force schema cache refresh
NOTIFY pgrst, 'reload schema';

SELECT 'RPC function created. Notifications will use this to bypass RLS.' AS status;
