-- ============================================================
-- ONLYFANS CLONE - ROW LEVEL SECURITY POLICIES
-- NO INFINITE RECURSION - All policies use direct auth.uid() checks
-- Run this AFTER migration.sql
-- ============================================================

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE post_likes ENABLE ROW LEVEL SECURITY;
ALTER TABLE stories ENABLE ROW LEVEL SECURITY;
ALTER TABLE story_views ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE vip_videos ENABLE ROW LEVEL SECURITY;
ALTER TABLE vip_purchases ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_rooms ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE verified_badge_subs ENABLE ROW LEVEL SECURITY;
ALTER TABLE creator_payment_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE site_settings ENABLE ROW LEVEL SECURITY;

-- Drop existing policies for clean re-run
DO $$ BEGIN
    -- Drop all existing policies
    DROP POLICY IF EXISTS "profiles_select" ON profiles;
    DROP POLICY IF EXISTS "profiles_insert" ON profiles;
    DROP POLICY IF EXISTS "profiles_update" ON profiles;
    DROP POLICY IF EXISTS "posts_select" ON posts;
    DROP POLICY IF EXISTS "posts_insert" ON posts;
    DROP POLICY IF EXISTS "posts_update" ON posts;
    DROP POLICY IF EXISTS "posts_delete" ON posts;
    DROP POLICY IF EXISTS "post_likes_select" ON post_likes;
    DROP POLICY IF EXISTS "post_likes_insert" ON post_likes;
    DROP POLICY IF EXISTS "post_likes_delete" ON post_likes;
    DROP POLICY IF EXISTS "stories_select" ON stories;
    DROP POLICY IF EXISTS "stories_insert" ON stories;
    DROP POLICY IF EXISTS "story_views_select" ON story_views;
    DROP POLICY IF EXISTS "story_views_insert" ON story_views;
    DROP POLICY IF EXISTS "subs_select" ON subscriptions;
    DROP POLICY IF EXISTS "subs_insert" ON subscriptions;
    DROP POLICY IF EXISTS "subs_update" ON subscriptions;
    DROP POLICY IF EXISTS "vip_videos_select" ON vip_videos;
    DROP POLICY IF EXISTS "vip_videos_insert" ON vip_videos;
    DROP POLICY IF EXISTS "vip_purchases_select" ON vip_purchases;
    DROP POLICY IF EXISTS "vip_purchases_insert" ON vip_purchases;
    DROP POLICY IF EXISTS "chat_rooms_select" ON chat_rooms;
    DROP POLICY IF EXISTS "chat_rooms_insert" ON chat_rooms;
    DROP POLICY IF EXISTS "chat_rooms_update" ON chat_rooms;
    DROP POLICY IF EXISTS "messages_select" ON messages;
    DROP POLICY IF EXISTS "messages_insert" ON messages;
    DROP POLICY IF EXISTS "tx_select" ON transactions;
    DROP POLICY IF EXISTS "tx_insert" ON transactions;
    DROP POLICY IF EXISTS "payments_select" ON payments;
    DROP POLICY IF EXISTS "payments_insert" ON payments;
    DROP POLICY IF EXISTS "notifs_select" ON notifications;
    DROP POLICY IF EXISTS "notifs_insert" ON notifications;
    DROP POLICY IF EXISTS "notifs_update" ON notifications;
    DROP POLICY IF EXISTS "badge_select" ON verified_badge_subs;
    DROP POLICY IF EXISTS "badge_insert" ON verified_badge_subs;
    DROP POLICY IF EXISTS "badge_update" ON verified_badge_subs;
    DROP POLICY IF EXISTS "creator_pay_select" ON creator_payment_settings;
    DROP POLICY IF EXISTS "creator_pay_insert" ON creator_payment_settings;
    DROP POLICY IF EXISTS "creator_pay_update" ON creator_payment_settings;
    DROP POLICY IF EXISTS "site_select" ON site_settings;
    DROP POLICY IF EXISTS "site_update" ON site_settings;
END $$;

-- PROFILES: public read, own write
CREATE POLICY "profiles_select" ON profiles FOR SELECT USING (true);
CREATE POLICY "profiles_insert" ON profiles FOR INSERT WITH CHECK (auth.uid() = id);
CREATE POLICY "profiles_update" ON profiles FOR UPDATE USING (auth.uid() = id);

-- POSTS: public read, own insert/update/delete
CREATE POLICY "posts_select" ON posts FOR SELECT USING (true);
CREATE POLICY "posts_insert" ON posts FOR INSERT WITH CHECK (auth.uid() = creator_id);
CREATE POLICY "posts_update" ON posts FOR UPDATE USING (auth.uid() = creator_id);
CREATE POLICY "posts_delete" ON posts FOR DELETE USING (auth.uid() = creator_id);

-- POST LIKES
CREATE POLICY "post_likes_select" ON post_likes FOR SELECT USING (true);
CREATE POLICY "post_likes_insert" ON post_likes FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "post_likes_delete" ON post_likes FOR DELETE USING (auth.uid() = user_id);

-- STORIES
CREATE POLICY "stories_select" ON stories FOR SELECT USING (expires_at > NOW());
CREATE POLICY "stories_insert" ON stories FOR INSERT WITH CHECK (auth.uid() = creator_id);

-- STORY VIEWS
CREATE POLICY "story_views_select" ON story_views FOR SELECT USING (true);
CREATE POLICY "story_views_insert" ON story_views FOR INSERT WITH CHECK (auth.uid() = viewer_id);

-- SUBSCRIPTIONS
CREATE POLICY "subs_select" ON subscriptions FOR SELECT USING (auth.uid() = subscriber_id OR auth.uid() = creator_id);
CREATE POLICY "subs_insert" ON subscriptions FOR INSERT WITH CHECK (auth.uid() = subscriber_id);
CREATE POLICY "subs_update" ON subscriptions FOR UPDATE USING (auth.uid() = creator_id OR auth.uid() = subscriber_id);

-- VIP VIDEOS
CREATE POLICY "vip_videos_select" ON vip_videos FOR SELECT USING (true);
CREATE POLICY "vip_videos_insert" ON vip_videos FOR INSERT WITH CHECK (auth.uid() = creator_id);

-- VIP PURCHASES
CREATE POLICY "vip_purchases_select" ON vip_purchases FOR SELECT USING (auth.uid() = buyer_id);
CREATE POLICY "vip_purchases_insert" ON vip_purchases FOR INSERT WITH CHECK (auth.uid() = buyer_id);

-- CHAT ROOMS
CREATE POLICY "chat_rooms_select" ON chat_rooms FOR SELECT USING (auth.uid() = participant_1 OR auth.uid() = participant_2);
CREATE POLICY "chat_rooms_insert" ON chat_rooms FOR INSERT WITH CHECK (auth.uid() = participant_1 OR auth.uid() = participant_2);
CREATE POLICY "chat_rooms_update" ON chat_rooms FOR UPDATE USING (auth.uid() = participant_1 OR auth.uid() = participant_2);

-- MESSAGES
CREATE POLICY "messages_select" ON messages FOR SELECT USING (EXISTS (SELECT 1 FROM chat_rooms cr WHERE cr.id = messages.room_id AND (cr.participant_1 = auth.uid() OR cr.participant_2 = auth.uid())));
CREATE POLICY "messages_insert" ON messages FOR INSERT WITH CHECK (auth.uid() = sender_id AND EXISTS (SELECT 1 FROM chat_rooms cr WHERE cr.id = messages.room_id AND (cr.participant_1 = auth.uid() OR cr.participant_2 = auth.uid())));

-- TRANSACTIONS
CREATE POLICY "tx_select" ON transactions FOR SELECT USING (auth.uid() = from_user OR auth.uid() = to_user);
CREATE POLICY "tx_insert" ON transactions FOR INSERT WITH CHECK (auth.uid() = from_user OR auth.uid() = to_user);

-- PAYMENTS
CREATE POLICY "payments_select" ON payments FOR SELECT USING (auth.uid() = user_id OR auth.uid() = creator_id);
CREATE POLICY "payments_insert" ON payments FOR INSERT WITH CHECK (auth.uid() = user_id);

-- NOTIFICATIONS
CREATE POLICY "notifs_select" ON notifications FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "notifs_insert" ON notifications FOR INSERT WITH CHECK (true);
CREATE POLICY "notifs_update" ON notifications FOR UPDATE USING (auth.uid() = user_id);

-- VERIFIED BADGE
CREATE POLICY "badge_select" ON verified_badge_subs FOR SELECT USING (auth.uid() = creator_id);
CREATE POLICY "badge_insert" ON verified_badge_subs FOR INSERT WITH CHECK (auth.uid() = creator_id);
CREATE POLICY "badge_update" ON verified_badge_subs FOR UPDATE USING (auth.uid() = creator_id);

-- CREATOR PAYMENT SETTINGS
CREATE POLICY "creator_pay_select" ON creator_payment_settings FOR SELECT USING (true);
CREATE POLICY "creator_pay_insert" ON creator_payment_settings FOR INSERT WITH CHECK (auth.uid() = creator_id);
CREATE POLICY "creator_pay_update" ON creator_payment_settings FOR UPDATE USING (auth.uid() = creator_id);

-- SITE SETTINGS
CREATE POLICY "site_select" ON site_settings FOR SELECT USING (true);
CREATE POLICY "site_update" ON site_settings FOR UPDATE USING (auth.uid() IS NOT NULL);

SELECT 'RLS policies applied successfully!' AS status;
