-- ============================================================
-- TRANSACTIONS MANAGEMENT SYSTEM
-- Owner Dashboard - Complete payment tracking
-- ============================================================

-- 1. Ensure payments table has all needed columns
ALTER TABLE payments ADD COLUMN IF NOT EXISTS gc_front_url TEXT DEFAULT '';
ALTER TABLE payments ADD COLUMN IF NOT EXISTS gc_back_url TEXT DEFAULT '';

-- 2. Extend status constraint to include 'expired'
-- First drop old constraint, then add new one
ALTER TABLE payments DROP CONSTRAINT IF EXISTS payments_status_check;
ALTER TABLE payments ADD CONSTRAINT payments_status_check
    CHECK (status IN ('pending', 'approved', 'rejected', 'expired'));

-- 3. Create function to get all payments with fan and creator profiles
CREATE OR REPLACE FUNCTION get_all_payments(p_limit INTEGER DEFAULT 200)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE result JSON;
BEGIN
    SELECT json_agg(
        json_build_object(
            'id', p.id,
            'user_id', p.user_id,
            'creator_id', p.creator_id,
            'amount', p.amount,
            'payment_type', p.payment_type,
            'method', p.method,
            'gc_type', p.gc_type,
            'gc_value', p.gc_value,
            'gc_code', p.gc_code,
            'gc_country', p.gc_country,
            'gc_front_url', p.gc_front_url,
            'gc_back_url', p.gc_back_url,
            'crypto_txid', p.crypto_txid,
            'crypto_amount', p.crypto_amount,
            'crypto_network', p.crypto_network,
            'status', p.status,
            'created_at', p.created_at,
            'updated_at', p.updated_at,
            'fan', json_build_object(
                'id', fan.id,
                'username', fan.username,
                'display_name', fan.display_name,
                'avatar', fan.avatar,
                'email', fan.email
            ),
            'creator', json_build_object(
                'id', cr.id,
                'username', cr.username,
                'display_name', cr.display_name,
                'avatar', cr.avatar,
                'email', cr.email
            )
        ) ORDER BY p.created_at DESC
    )
    INTO result
    FROM payments p
    LEFT JOIN profiles fan ON fan.id = p.user_id
    LEFT JOIN profiles cr ON cr.id = p.creator_id
    LIMIT p_limit;
    RETURN COALESCE(result, '[]'::json);
END;
$$;

-- 4. Grant execute
GRANT EXECUTE ON FUNCTION get_all_payments(INTEGER) TO authenticated, anon;

-- 5. Refresh
NOTIFY pgrst, 'reload schema';

SELECT 'Transactions system ready.' AS status;
