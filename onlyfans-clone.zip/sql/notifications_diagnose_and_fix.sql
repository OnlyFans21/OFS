-- ============================================================
-- DIAGNOSE AND FIX NOTIFICATIONS RLS
-- Step 1: Diagnose what exists
-- Step 2: Drop everything old
-- Step 3: Create correct policies
-- ============================================================

-- ============================================================
-- STEP 1: DIAGNOSE - Show everything on the notifications table
-- ============================================================

-- 1a. Show all policies (including who they apply to)
SELECT '=== CURRENT POLICIES ===' AS section;
SELECT policyname, permissive, roles::text, cmd, qual, with_check
FROM pg_policies
WHERE tablename = 'notifications'
ORDER BY policyname;

-- 1b. Show all triggers on the table
SELECT '=== TRIGGERS ===' AS section;
SELECT trigger_name, event_manipulation, action_timing, action_statement
FROM information_schema.triggers
WHERE event_object_table = 'notifications';

-- 1c. Show all CHECK constraints
SELECT '=== CHECK CONSTRAINTS ===' AS section;
SELECT conname, pg_get_constraintdef(oid) AS constraint_def
FROM pg_constraint
WHERE conrelid = 'notifications'::regclass AND contype = 'c';

-- 1d. Show column types
SELECT '=== COLUMNS ===' AS section;
SELECT column_name, data_type, is_nullable, column_default
FROM information_schema.columns
WHERE table_name = 'notifications'
ORDER BY ordinal_position;

-- ============================================================
-- STEP 2: DROP ALL EXISTING POLICIES (two methods for thoroughness)
-- ============================================================

-- Method A: Drop by name (covers known policies)
DROP POLICY IF EXISTS "sel" ON notifications;
DROP POLICY IF EXISTS "ins" ON notifications;
DROP POLICY IF EXISTS "upd" ON notifications;
DROP POLICY IF EXISTS "del" ON notifications;
DROP POLICY IF EXISTS "n_select" ON notifications;
DROP POLICY IF EXISTS "n_insert" ON notifications;
DROP POLICY IF EXISTS "n_update" ON notifications;
DROP POLICY IF EXISTS "n_delete" ON notifications;
DROP POLICY IF EXISTS "notifs_select_own" ON notifications;
DROP POLICY IF EXISTS "notifs_insert" ON notifications;
DROP POLICY IF EXISTS "notifs_insert_system" ON notifications;
DROP POLICY IF EXISTS "notifs_update_own" ON notifications;
DROP POLICY IF EXISTS "notifs_delete_own" ON notifications;
DROP POLICY IF EXISTS "notifs_select" ON notifications;
DROP POLICY IF EXISTS "notifs_update" ON notifications;
DROP POLICY IF EXISTS "notifs_delete" ON notifications;

-- Method B: Loop through ALL policies on notifications (catches any we missed)
DO $$
DECLARE
    pol RECORD;
BEGIN
    FOR pol IN SELECT policyname FROM pg_policies WHERE tablename = 'notifications'
    LOOP
        EXECUTE format('DROP POLICY IF EXISTS %I ON notifications', pol.policyname);
    END LOOP;
END $$;

-- ============================================================
-- STEP 3: Verify policies are gone
-- ============================================================
SELECT '=== AFTER DROP ===' AS section;
SELECT COUNT(*) AS remaining_policies FROM pg_policies WHERE tablename = 'notifications';

-- ============================================================
-- STEP 4: Re-enable RLS (ensure it's on)
-- ============================================================
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

-- ============================================================
-- STEP 5: Create 4 clean policies with unique names
-- ============================================================

-- SELECT: Users see only their own notifications
CREATE POLICY "n_select" ON notifications
    FOR SELECT TO authenticated
    USING (user_id = auth.uid());

-- INSERT: Authenticated users can create notifications.
-- user_id in the payload is the RECIPIENT (fan), not the sender (creator).
-- This is correct because creators send notifications TO fans.
CREATE POLICY "n_insert" ON notifications
    FOR INSERT TO authenticated
    WITH CHECK (true);

-- UPDATE: Users can only update their own notifications (mark as read)
CREATE POLICY "n_update" ON notifications
    FOR UPDATE TO authenticated
    USING (user_id = auth.uid());

-- DELETE: Users can only delete their own notifications
CREATE POLICY "n_delete" ON notifications
    FOR DELETE TO authenticated
    USING (user_id = auth.uid());

-- ============================================================
-- STEP 6: Verify new policies
-- ============================================================
SELECT '=== NEW POLICIES ===' AS section;
SELECT policyname, cmd, qual, with_check
FROM pg_policies
WHERE tablename = 'notifications'
ORDER BY policyname;

-- ============================================================
-- STEP 7: Force schema cache refresh
-- ============================================================
NOTIFY pgrst, 'reload schema';

SELECT 'RLS fix complete. Old policies dropped, new policies created.' AS status;
