-- ============================================================
-- FIX: Boosted likes disappearing after fan like/unlike
-- Root cause: toggle_post_like recalculates profiles.likes_count
-- using SUM(likes_count) only, NOT including boosted_likes.
-- When a fan likes/unlikes, it overwrites the correct total.
-- ============================================================

-- Recreate toggle_post_like with CORRECT profile likes calculation
-- Includes boosted_likes in the SUM
CREATE OR REPLACE FUNCTION toggle_post_like(p_post_id UUID, p_user_id UUID)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    existing_id UUID;
    creator_uid UUID;
    new_liked BOOLEAN;
    post_likes_now INTEGER;
BEGIN
    -- Get the creator_id for this post
    SELECT creator_id INTO creator_uid FROM posts WHERE id = p_post_id;
    IF creator_uid IS NULL THEN
        RETURN json_build_object('liked', false, 'likes_count', 0, 'error', 'Post not found');
    END IF;

    -- Check if already liked
    SELECT id INTO existing_id FROM post_likes WHERE post_id = p_post_id AND user_id = p_user_id;

    IF existing_id IS NOT NULL THEN
        -- Unlike: delete the like
        DELETE FROM post_likes WHERE id = existing_id;
        new_liked := false;
    ELSE
        -- Like: insert new like (ignore duplicate key)
        BEGIN
            INSERT INTO post_likes (post_id, user_id) VALUES (p_post_id, p_user_id);
        EXCEPTION WHEN unique_violation THEN
            -- Already liked somehow, treat as unlike
            DELETE FROM post_likes WHERE post_id = p_post_id AND user_id = p_user_id;
            new_liked := false;
            -- Recalculate
            SELECT COUNT(*) INTO post_likes_now FROM post_likes WHERE post_id = p_post_id;
            UPDATE posts SET likes_count = post_likes_now WHERE id = p_post_id;
            -- FIXED: Include boosted_likes in profile total
            UPDATE profiles SET likes_count = (
                SELECT COALESCE(SUM(likes_count + COALESCE(boosted_likes, 0)), 0)
                FROM posts WHERE creator_id = creator_uid
            ) WHERE id = creator_uid;
            RETURN json_build_object('liked', false, 'likes_count', post_likes_now);
        END;
        new_liked := true;
    END IF;

    -- Recalculate actual like count for this post
    SELECT COUNT(*) INTO post_likes_now FROM post_likes WHERE post_id = p_post_id;

    -- Update posts.likes_count (real fan likes only)
    UPDATE posts SET likes_count = post_likes_now WHERE id = p_post_id;

    -- FIXED: Update profiles.likes_count INCLUDING boosted_likes
    -- (real likes + boosted likes combined)
    UPDATE profiles SET likes_count = (
        SELECT COALESCE(SUM(likes_count + COALESCE(boosted_likes, 0)), 0)
        FROM posts WHERE creator_id = creator_uid
    ) WHERE id = creator_uid;

    RETURN json_build_object('liked', new_liked, 'likes_count', post_likes_now);
END;
$$;

-- Also ensure boost_post_likes function is correct
CREATE OR REPLACE FUNCTION boost_post_likes(p_post_id UUID, p_boost_amount INTEGER)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    creator_uid UUID;
    old_boosted INTEGER;
    new_boosted INTEGER;
    post_likes_now INTEGER;
BEGIN
    SELECT creator_id, COALESCE(boosted_likes, 0) INTO creator_uid, old_boosted
    FROM posts WHERE id = p_post_id;

    IF creator_uid IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Post not found');
    END IF;

    new_boosted := old_boosted + p_boost_amount;

    -- Update post boosted_likes
    UPDATE posts SET boosted_likes = new_boosted WHERE id = p_post_id;

    -- Get current real likes
    SELECT COUNT(*) INTO post_likes_now FROM post_likes WHERE post_id = p_post_id;

    -- Update posts.likes_count to match real count
    UPDATE posts SET likes_count = post_likes_now WHERE id = p_post_id;

    -- Update profiles.likes_count (real + boosted)
    UPDATE profiles SET likes_count = (
        SELECT COALESCE(SUM(likes_count + COALESCE(boosted_likes, 0)), 0)
        FROM posts WHERE creator_id = creator_uid
    ) WHERE id = creator_uid;

    RETURN json_build_object('success', true, 'boosted_likes', new_boosted, 'total_likes', post_likes_now + new_boosted);
END;
$$;

-- Also fix reset_post_boost
CREATE OR REPLACE FUNCTION reset_post_boost(p_post_id UUID)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    creator_uid UUID;
BEGIN
    SELECT creator_id INTO creator_uid FROM posts WHERE id = p_post_id;
    IF creator_uid IS NULL THEN RETURN false; END IF;

    UPDATE posts SET boosted_likes = 0 WHERE id = p_post_id;

    -- FIXED: Include likes_count + boosted_likes in the recalculation
    UPDATE profiles SET likes_count = (
        SELECT COALESCE(SUM(likes_count + COALESCE(boosted_likes, 0)), 0)
        FROM posts WHERE creator_id = creator_uid
    ) WHERE id = creator_uid;

    RETURN true;
END;
$$;

-- Grant permissions
GRANT EXECUTE ON FUNCTION toggle_post_like(UUID, UUID) TO authenticated, anon;
GRANT EXECUTE ON FUNCTION boost_post_likes(UUID, INTEGER) TO authenticated, anon;
GRANT EXECUTE ON FUNCTION reset_post_boost(UUID) TO authenticated, anon;

-- Refresh
NOTIFY pgrst, 'reload schema';

SELECT 'toggle_post_like now includes boosted_likes in profile total. Boosts are permanent.' AS status;
