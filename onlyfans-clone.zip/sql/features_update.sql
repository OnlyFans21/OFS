-- ============================================================
-- FEATURES UPDATE SQL
-- VIP Subscribers Management, Notifications, Likes fixes
-- Safe to run multiple times
-- ============================================================

-- 1. ADD notifications table
CREATE TABLE IF NOT EXISTS notifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
    type TEXT NOT NULL DEFAULT 'general',
    title TEXT NOT NULL DEFAULT '',
    body TEXT DEFAULT '',
    related_id TEXT DEFAULT '',
    related_type TEXT DEFAULT '',
    is_read BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS on notifications
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

-- Drop existing policies to avoid conflicts
DROP POLICY IF EXISTS "notifs_select_own" ON notifications;
DROP POLICY IF EXISTS "notifs_insert_system" ON notifications;
DROP POLICY IF EXISTS "notifs_update_own" ON notifications;
DROP POLICY IF EXISTS "notifs_delete_own" ON notifications;

-- Notifications policies: users can only see their own notifications
CREATE POLICY "notifs_select_own" ON notifications FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "notifs_insert_system" ON notifications FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY "notifs_update_own" ON notifications FOR UPDATE TO authenticated USING (user_id = auth.uid());
CREATE POLICY "notifs_delete_own" ON notifications FOR DELETE TO authenticated USING (user_id = auth.uid());

-- 2. Ensure vip_purchases table has all needed columns
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='vip_purchases' AND column_name='expires_at') THEN
        ALTER TABLE vip_purchases ADD COLUMN expires_at TIMESTAMPTZ;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='vip_purchases' AND column_name='approved_at') THEN
        ALTER TABLE vip_purchases ADD COLUMN approved_at TIMESTAMPTZ;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='vip_purchases' AND column_name='payment_method') THEN
        ALTER TABLE vip_purchases ADD COLUMN payment_method TEXT DEFAULT '';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='vip_purchases' AND column_name='declined_at') THEN
        ALTER TABLE vip_purchases ADD COLUMN declined_at TIMESTAMPTZ;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='vip_purchases' AND column_name='decline_reason') THEN
        ALTER TABLE vip_purchases ADD COLUMN decline_reason TEXT DEFAULT '';
    END IF;
END $$;

-- 3. Ensure posts table has boosted_likes column
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='posts' AND column_name='boosted_likes') THEN
        ALTER TABLE posts ADD COLUMN boosted_likes INTEGER DEFAULT 0;
    END IF;
END $$;

-- 4. Ensure profiles table has likes_count column
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='profiles' AND column_name='likes_count') THEN
        ALTER TABLE profiles ADD COLUMN likes_count INTEGER DEFAULT 0;
    END IF;
END $$;

-- 5. Create function to update profile likes_count
CREATE OR REPLACE FUNCTION update_profile_likes_count()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        UPDATE profiles SET likes_count = COALESCE(likes_count, 0) + 1 WHERE id = (
            SELECT creator_id FROM posts WHERE id = NEW.post_id
        );
        RETURN NEW;
    ELSIF TG_OP = 'DELETE' THEN
        UPDATE profiles SET likes_count = GREATEST(COALESCE(likes_count, 0) - 1, 0) WHERE id = (
            SELECT creator_id FROM posts WHERE id = OLD.post_id
        );
        RETURN OLD;
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Drop existing trigger if exists
DROP TRIGGER IF EXISTS trg_update_profile_likes ON post_likes;

-- Create trigger
CREATE TRIGGER trg_update_profile_likes
AFTER INSERT OR DELETE ON post_likes
FOR EACH ROW
EXECUTE FUNCTION update_profile_likes_count();

-- 6. Create function to expire VIP purchases after 2 days
CREATE OR REPLACE FUNCTION expire_vip_purchases()
RETURNS void AS $$
BEGIN
    UPDATE vip_purchases 
    SET status = 'expired', updated_at = now()
    WHERE status = 'approved' 
    AND approved_at IS NOT NULL
    AND now() > (approved_at + interval '2 days');
END;
$$ LANGUAGE plpgsql;

-- 7. Create index for faster notification queries
CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_unread ON notifications(user_id, is_read);
CREATE INDEX IF NOT EXISTS idx_vip_purchases_buyer ON vip_purchases(buyer_id);
CREATE INDEX IF NOT EXISTS idx_vip_purchases_video ON vip_purchases(video_id);
CREATE INDEX IF NOT EXISTS idx_vip_purchases_status ON vip_purchases(status);

SELECT 'Features update completed successfully!' AS status;
