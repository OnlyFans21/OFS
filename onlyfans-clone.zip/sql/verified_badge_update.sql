-- ============================================================
-- VERIFIED BLUE BADGE SUBSCRIPTION SYSTEM UPDATE
-- Run this AFTER migration.sql, rls_policies.sql, storage_policies.sql
-- ============================================================

-- ============================================================
-- 1. ADD COLUMNS TO VERIFIED_BADGE_SUBS TABLE
-- ============================================================

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='verified_badge_subs' AND column_name='full_name') THEN
        ALTER TABLE verified_badge_subs ADD COLUMN full_name TEXT DEFAULT '';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='verified_badge_subs' AND column_name='username') THEN
        ALTER TABLE verified_badge_subs ADD COLUMN username TEXT DEFAULT '';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='verified_badge_subs' AND column_name='email') THEN
        ALTER TABLE verified_badge_subs ADD COLUMN email TEXT DEFAULT '';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='verified_badge_subs' AND column_name='payment_reference') THEN
        ALTER TABLE verified_badge_subs ADD COLUMN payment_reference TEXT DEFAULT '';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='verified_badge_subs' AND column_name='screenshot_url') THEN
        ALTER TABLE verified_badge_subs ADD COLUMN screenshot_url TEXT DEFAULT '';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='verified_badge_subs' AND column_name='note') THEN
        ALTER TABLE verified_badge_subs ADD COLUMN note TEXT DEFAULT '';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='verified_badge_subs' AND column_name='bank_name') THEN
        ALTER TABLE verified_badge_subs ADD COLUMN bank_name TEXT DEFAULT 'PalmPay';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='verified_badge_subs' AND column_name='account_name') THEN
        ALTER TABLE verified_badge_subs ADD COLUMN account_name TEXT DEFAULT 'Palm Pay';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='verified_badge_subs' AND column_name='account_number') THEN
        ALTER TABLE verified_badge_subs ADD COLUMN account_number TEXT DEFAULT '8061762411';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='verified_badge_subs' AND column_name='amount_paid') THEN
        ALTER TABLE verified_badge_subs ADD COLUMN amount_paid TEXT DEFAULT '';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='verified_badge_subs' AND column_name='price_usd') THEN
        ALTER TABLE verified_badge_subs ADD COLUMN price_usd DECIMAL(10,2) DEFAULT 8.00;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='verified_badge_subs' AND column_name='price_ngn') THEN
        ALTER TABLE verified_badge_subs ADD COLUMN price_ngn DECIMAL(10,2) DEFAULT 11200.00;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='verified_badge_subs' AND column_name='activated_at') THEN
        ALTER TABLE verified_badge_subs ADD COLUMN activated_at TIMESTAMPTZ;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='verified_badge_subs' AND column_name='rejected_reason') THEN
        ALTER TABLE verified_badge_subs ADD COLUMN rejected_reason TEXT DEFAULT '';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='verified_badge_subs' AND column_name='date_of_payment') THEN
        ALTER TABLE verified_badge_subs ADD COLUMN date_of_payment TEXT DEFAULT '';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='verified_badge_subs' AND column_name='updated_at') THEN
        ALTER TABLE verified_badge_subs ADD COLUMN updated_at TIMESTAMPTZ DEFAULT NOW();
    END IF;
END $$;

-- Update status check constraint
ALTER TABLE verified_badge_subs DROP CONSTRAINT IF EXISTS verified_badge_subs_status_check;
ALTER TABLE verified_badge_subs ADD CONSTRAINT verified_badge_subs_status_check CHECK (status IN ('pending', 'active', 'expired', 'rejected', 'suspended'));

-- Trigger for updated_at
CREATE OR REPLACE FUNCTION update_verified_badge_updated_at()
RETURNS TRIGGER AS $$ BEGIN NEW.updated_at = NOW(); RETURN NEW; END; $$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS tr_verified_badge_updated ON verified_badge_subs;
CREATE TRIGGER tr_verified_badge_updated BEFORE UPDATE ON verified_badge_subs FOR EACH ROW EXECUTE FUNCTION update_verified_badge_updated_at();

-- ============================================================
-- 2. ADD BADGE PRICE COLUMNS TO SITE_SETTINGS
-- ============================================================

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='site_settings' AND column_name='badge_price_usd') THEN
        ALTER TABLE site_settings ADD COLUMN badge_price_usd DECIMAL(10,2) DEFAULT 8.00;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='site_settings' AND column_name='badge_price_ngn') THEN
        ALTER TABLE site_settings ADD COLUMN badge_price_ngn DECIMAL(10,2) DEFAULT 11200.00;
    END IF;
END $$;

UPDATE site_settings SET badge_price_usd = COALESCE(badge_price_usd, 8.00), badge_price_ngn = COALESCE(badge_price_ngn, 11200.00) WHERE id = 1;

-- ============================================================
-- 3. STORAGE BUCKET FOR BADGE SCREENSHOTS
-- ============================================================

INSERT INTO storage.buckets (id, name, public) VALUES ('badge-screenshots', 'badge-screenshots', true) ON CONFLICT (id) DO NOTHING;

-- ============================================================
-- 4. RLS POLICIES FOR VERIFIED_BADGE_SUBS
-- ============================================================

ALTER TABLE verified_badge_subs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS vbs_select_public ON verified_badge_subs;
DROP POLICY IF EXISTS vbs_select_own ON verified_badge_subs;
DROP POLICY IF EXISTS vbs_insert_own ON verified_badge_subs;
DROP POLICY IF EXISTS vbs_update_own ON verified_badge_subs;
DROP POLICY IF EXISTS vbs_select_all ON verified_badge_subs;
DROP POLICY IF EXISTS vbs_update_all ON verified_badge_subs;
DROP POLICY IF EXISTS vbs_delete_all ON verified_badge_subs;

CREATE POLICY vbs_select_public ON verified_badge_subs FOR SELECT USING (status = 'active');
CREATE POLICY vbs_select_own ON verified_badge_subs FOR SELECT USING (creator_id = auth.uid());
CREATE POLICY vbs_insert_own ON verified_badge_subs FOR INSERT WITH CHECK (creator_id = auth.uid());
CREATE POLICY vbs_update_own ON verified_badge_subs FOR UPDATE USING (creator_id = auth.uid());
CREATE POLICY vbs_select_all ON verified_badge_subs FOR SELECT TO authenticated USING (true);
CREATE POLICY vbs_update_all ON verified_badge_subs FOR UPDATE TO authenticated USING (true);
CREATE POLICY vbs_delete_all ON verified_badge_subs FOR DELETE TO authenticated USING (true);

-- ============================================================
-- 5. STORAGE POLICIES FOR BADGE-SCREENSHOTS
-- ============================================================

DROP POLICY IF EXISTS badge_screenshots_read ON storage.objects;
DROP POLICY IF EXISTS badge_screenshots_insert ON storage.objects;
DROP POLICY IF EXISTS badge_screenshots_delete ON storage.objects;

CREATE POLICY badge_screenshots_read ON storage.objects FOR SELECT USING (bucket_id = 'badge-screenshots');
CREATE POLICY badge_screenshots_insert ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'badge-screenshots' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY badge_screenshots_delete ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'badge-screenshots' AND (storage.foldername(name))[1] = auth.uid()::text);

-- ============================================================
-- 6. REALTIME
-- ============================================================

ALTER PUBLICATION supabase_realtime ADD TABLE verified_badge_subs;

-- ============================================================
-- 7. AUTO-EXPIRY FUNCTION
-- ============================================================

CREATE OR REPLACE FUNCTION expire_verified_badges()
RETURNS void AS $$
BEGIN
    UPDATE verified_badge_subs SET status = 'expired' WHERE status = 'active' AND expires_at < NOW();
    UPDATE profiles SET verified = false WHERE id IN (
        SELECT creator_id FROM verified_badge_subs WHERE status = 'expired' AND verified = true
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

SELECT expire_verified_badges();

SELECT 'Verified Badge System update completed!' AS status;
