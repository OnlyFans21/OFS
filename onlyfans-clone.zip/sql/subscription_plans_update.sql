-- ============================================================
-- SUBSCRIPTION PLANS SYSTEM UPDATE
-- Run this AFTER migration.sql and payment_system_update.sql
-- Safe to run multiple times
-- ============================================================

-- 1. CREATE subscription_plans TABLE
CREATE TABLE IF NOT EXISTS subscription_plans (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    creator_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    plan_type TEXT NOT NULL CHECK (plan_type IN ('weekly', 'monthly', 'vip')),
    price DECIMAL(10,2) NOT NULL DEFAULT 0,
    enabled BOOLEAN DEFAULT TRUE,
    sort_order INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(creator_id, plan_type)
);

CREATE INDEX IF NOT EXISTS idx_sub_plans_creator ON subscription_plans(creator_id);
CREATE INDEX IF NOT EXISTS idx_sub_plans_type ON subscription_plans(plan_type);

-- Trigger for updated_at
CREATE OR REPLACE FUNCTION update_sub_plans_updated_at()
RETURNS TRIGGER AS $$ BEGIN NEW.updated_at = NOW(); RETURN NEW; END; $$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS tr_sub_plans_updated ON subscription_plans;
CREATE TRIGGER tr_sub_plans_updated BEFORE UPDATE ON subscription_plans FOR EACH ROW EXECUTE FUNCTION update_sub_plans_updated_at();

-- 2. MIGRATE existing prices from profiles to subscription_plans
-- Insert default plans for every creator that doesn't have them
INSERT INTO subscription_plans (creator_id, plan_type, price, enabled, sort_order)
SELECT 
    p.id,
    plan.plan_type,
    CASE plan.plan_type
        WHEN 'monthly' THEN COALESCE(p.monthly_price, 20)
        WHEN 'weekly' THEN COALESCE(p.weekly_price, 5)
        WHEN 'vip' THEN COALESCE(p.vip_price, 50)
    END,
    TRUE,
    CASE plan.plan_type
        WHEN 'weekly' THEN 1
        WHEN 'monthly' THEN 2
        WHEN 'vip' THEN 3
    END
FROM profiles p
CROSS JOIN (VALUES ('weekly'), ('monthly'), ('vip')) AS plan(plan_type)
WHERE p.type = 'creator'
ON CONFLICT (creator_id, plan_type) DO NOTHING;

-- 3. RLS POLICIES FOR subscription_plans
ALTER TABLE subscription_plans ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "sub_plans_select" ON subscription_plans;
DROP POLICY IF EXISTS "sub_plans_insert" ON subscription_plans;
DROP POLICY IF EXISTS "sub_plans_update" ON subscription_plans;
DROP POLICY IF EXISTS "sub_plans_delete" ON subscription_plans;

-- Public can see enabled plans
CREATE POLICY "sub_plans_select" ON subscription_plans FOR SELECT USING (enabled = TRUE OR creator_id = auth.uid());
-- Creators can manage their own plans
CREATE POLICY "sub_plans_insert" ON subscription_plans FOR INSERT WITH CHECK (creator_id = auth.uid());
CREATE POLICY "sub_plans_update" ON subscription_plans FOR UPDATE USING (creator_id = auth.uid());
CREATE POLICY "sub_plans_delete" ON subscription_plans FOR DELETE USING (creator_id = auth.uid());

-- 4. REALTIME
DO $$ BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE subscription_plans;
EXCEPTION WHEN OTHERS THEN
    RAISE NOTICE 'Realtime already added: %', SQLERRM;
END $$;

-- 5. HELPER FUNCTION: Get plan duration in days
CREATE OR REPLACE FUNCTION get_plan_duration(p_plan_type TEXT)
RETURNS INTEGER AS $$
BEGIN
    RETURN CASE p_plan_type
        WHEN 'weekly' THEN 7
        WHEN 'monthly' THEN 30
        WHEN 'vip' THEN 2
        ELSE 30
    END;
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- 6. HELPER FUNCTION: Calculate expiry date based on plan type
CREATE OR REPLACE FUNCTION calculate_subscription_expiry(p_plan_type TEXT)
RETURNS TIMESTAMPTZ AS $$
BEGIN
    RETURN NOW() + (get_plan_duration(p_plan_type) || ' days')::INTERVAL;
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- 7. UPDATE the payment approval trigger to use plan-based expiry
DROP TRIGGER IF EXISTS tr_payment_approved ON payments;
DROP FUNCTION IF EXISTS approve_payment_and_subscribe();

CREATE OR REPLACE FUNCTION approve_payment_and_subscribe()
RETURNS TRIGGER AS $$
DECLARE
    v_plan_type TEXT;
    v_duration_days INTEGER;
BEGIN
    IF NEW.status = 'approved' AND OLD.status = 'pending' THEN
        v_plan_type := COALESCE(NEW.payment_type, 'monthly');
        v_duration_days := get_plan_duration(v_plan_type);
        
        INSERT INTO public.subscriptions (subscriber_id, creator_id, plan_type, amount, status, expires_at, subscription_status)
        VALUES (NEW.user_id, NEW.creator_id, v_plan_type, NEW.amount, 'approved', NOW() + (v_duration_days || ' days')::INTERVAL, 'active')
        ON CONFLICT (subscriber_id, creator_id)
        DO UPDATE SET
            status = 'approved',
            plan_type = v_plan_type,
            amount = NEW.amount,
            expires_at = NOW() + (v_duration_days || ' days')::INTERVAL,
            subscription_status = 'active',
            updated_at = NOW();
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER tr_payment_approved
    AFTER UPDATE OF status ON payments
    FOR EACH ROW
    WHEN (NEW.status = 'approved' AND OLD.status = 'pending')
    EXECUTE FUNCTION approve_payment_and_subscribe();

-- 8. AUTO-EXPIRY FUNCTION (runs periodically)
CREATE OR REPLACE FUNCTION expire_old_subscriptions()
RETURNS void AS $$
BEGIN
    -- Mark expired subscriptions
    UPDATE subscriptions
    SET subscription_status = 'disabled',
        status = 'expired'
    WHERE expires_at IS NOT NULL
      AND expires_at < NOW()
      AND status = 'approved'
      AND subscription_status = 'active';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

SELECT 'Subscription Plans system update completed!' AS status;
