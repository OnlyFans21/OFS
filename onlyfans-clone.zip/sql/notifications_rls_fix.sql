-- ============================================================
-- NOTIFICATIONS RLS - COMPLETE RESET AND FIX
-- Drops ALL policies, creates clean new ones
-- Safe to run multiple times
-- ============================================================

-- 1. Disable RLS temporarily (to clean up)
ALTER TABLE notifications DISABLE ROW LEVEL SECURITY;

-- 2. Drop ALL existing policies (clean slate - no conflicts)
DO $$
DECLARE
    pol RECORD;
BEGIN
    FOR pol IN SELECT policyname FROM pg_policies WHERE tablename = 'notifications'
    LOOP
        EXECUTE format('DROP POLICY IF EXISTS %I ON notifications', pol.policyname);
    END LOOP;
END $$;

-- 3. Re-enable RLS
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

-- 4. Force RLS for table owner too (bypass only via service_role)
ALTER TABLE notifications FORCE ROW LEVEL SECURITY;

-- 5. Create clean policies
-- SELECT: Users see ONLY their own notifications
CREATE POLICY "notifs_select_own"
    ON notifications FOR SELECT
    TO authenticated
    USING (user_id = auth.uid());

-- INSERT: Authenticated users can create notifications.
-- This MUST be permissive because creators send notifications to FANS
-- (cross-user notifications: payment approved, new post, new message, etc.)
-- The application logic controls who receives what.
CREATE POLICY "notifs_insert"
    ON notifications FOR INSERT
    TO authenticated
    WITH CHECK (true);

-- UPDATE: Users can only update (mark read) their own notifications
CREATE POLICY "notifs_update_own"
    ON notifications FOR UPDATE
    TO authenticated
    USING (user_id = auth.uid());

-- DELETE: Users can only delete their own notifications
CREATE POLICY "notifs_delete_own"
    ON notifications FOR DELETE
    TO authenticated
    USING (user_id = auth.uid());

-- 6. Verify: show all current policies
SELECT policyname, cmd, qual, with_check
FROM pg_policies
WHERE tablename = 'notifications'
ORDER BY policyname;

-- 7. Force schema cache refresh
NOTIFY pgrst, 'reload schema';
COMMENT ON TABLE notifications IS 'notifications-v3';

SELECT 'Notifications RLS reset complete!' AS status;
